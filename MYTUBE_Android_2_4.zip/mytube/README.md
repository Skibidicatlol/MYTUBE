# MYTUBE 2.4

Projeto Android nativo em Kotlin, Jetpack Compose, Material 3 e AndroidX Media3. O aplicativo é prioritariamente offline, usa perfil local e mantém vídeos importados no armazenamento privado do aplicativo.

## Melhorias da versão 2.4

- Barra de progresso do player redesenhada em tons neutros, sem o destaque vermelho anterior, com busca por toque e arraste.
- Botão de tela cheia solicita orientação horizontal do aparelho e restaura a orientação automática ao sair.
- Editor de thumbnail permite escolher uma imagem dos arquivos ou selecionar um frame do próprio vídeo.
- Mantida a chave fixa `mytube-debug.keystore` para preservar a assinatura entre builds desta linha de versões.

## Melhorias da versão 2.3

- Atualização por cima: assinatura fixa (`app/mytube-debug.keystore`) e `versionCode` 11, então novas versões instalam sem desinstalar e sem perder dados. Não troque nem apague esse arquivo.
- Tela gira em todo o app (`fullSensor`); o player continua com seu próprio modo de tela cheia.
- Categorias do Início com rolagem horizontal (sem quebrar "Roblox").
- Vídeos em lista compacta (miniatura 16:9 pequena à esquerda), sem o bloco grande.
- Player: controles com degradê e botões arredondados, coração no lugar do like, sem "não gostei", velocidade (0,5x a 2x) nas configurações, barra de progresso corrigida quando a duração ainda é desconhecida.

## Melhorias da versão 2.2

- Player redesenhado com título no topo, botões centrais de anterior/recomeçar, pausar/continuar e próximo, barra de progresso com tempo e ações de curtir/não gostei/salvar.
- Controles ocultos durante a reprodução; aparecem somente após toque. Gestos de arrastar ou passar o dedo não devem acionar os controles.
- O botão anterior retorna ao item anterior conhecido ou reinicia o vídeo atual quando não existe anterior; próximo respeita a fila, aleatório e repetição.
- Mantido o mesmo `applicationId` (`com.mytube.app`) para permitir atualização sobre a instalação anterior sem apagar dados locais.

## Melhorias preservadas da versão 2.1

- Editor de thumbnails disponível na biblioteca, nos itens do canal, na tela de reprodução e na experiência Shorts. A imagem escolhida é copiada para o armazenamento privado; é possível restaurar a miniatura automática.
- Fila de reprodução com remoção individual, limpeza completa, movimentação para cima/baixo e inclusão de recomendações na fila.
- Recomendações locais revisadas: correspondência de palavras do título, categorias inferidas pelo nome, categorias preferidas pelo usuário, curtidas, itens salvos e atividade local. As categorias preferidas são configuráveis em Configurações > Recomendações.
- Controles do player mantêm reiniciar/dois toques para voltar, pausa, próximo, configurações e fullscreen em grupos separados; editor de thumbnail também fica disponível na tela do player.
- Shorts exibem foto, nome e identificador do perfil local e permitem abrir o editor da thumbnail durante a navegação.
- Privacidade e permissões descrevem o uso do seletor de documentos do Android. O Manifest não declara permissões amplas de armazenamento, internet, câmera, microfone, localização, contatos ou notificações.
- Direitos e licenças listam as dependências diretas e respectivas licenças declaradas, com ressalva de dependências transitivas.

## Recursos preservados da 2.0

- Navegação inferior com Início, Shorts, Enviar e Você; Inscrições removida.
- Pesquisa local, Canal local e Configurações no topo do Início.
- Prateleira horizontal de Shorts com miniaturas personalizadas.
- Histórico exclusivamente em Você; sem seção Continuar assistindo.
- Perfil local com nome, identificador, descrição e foto da galeria.
- Curtidos, Assistir mais tarde e biblioteca local.
- Shorts com seleção automática aleatória, loop e navegação vertical; importação somente em Enviar.
- Player Media3, tela cheia automática em paisagem e recomendações locais abaixo do player.
- Playlists locais com criação, edição, remoção, ordenação, capa por vídeo ou imagem da galeria e reprodução.
- Temas escuro, claro e automático; preferências de reprodução; resumo de armazenamento; limpeza de cache.
- Importação de vídeos normais ou Shorts para `filesDir/videos`, com cópia privada e exclusão da cópia ao remover o item da biblioteca.

## Dependências diretas e licenças

| Componente | Versão declarada | Licença declarada |
|---|---:|---|
| Android Gradle Plugin | 8.9.1 | Apache License 2.0 |
| Kotlin / Kotlin Compose plugin | 2.1.10 | Apache License 2.0 |
| Compose BOM | 2025.02.00 | Apache License 2.0 para os artefatos Jetpack Compose listados |
| Compose UI / UI Tooling Preview | via BOM | Apache License 2.0 |
| Material 3 / Material Icons Extended | via BOM | Apache License 2.0 |
| AndroidX Activity Compose | 1.10.1 | Apache License 2.0 |
| Lifecycle Runtime KTX | 2.8.7 | Apache License 2.0 |
| Media3 ExoPlayer / UI / Common | 1.5.1 | Apache License 2.0 |

Referências oficiais: [Apache License 2.0](https://www.apache.org/licenses/LICENSE-2.0) · [AndroidX](https://developer.android.com/jetpack/androidx) · [Kotlin](https://kotlinlang.org/license.html). A tabela lista dependências diretas do projeto; artefatos transitivos podem conter avisos e licenças adicionais que dependem da resolução Gradle do build. Room e Coil não estão declarados nas dependências diretas atuais.

## Permissões e acesso a arquivos

O `AndroidManifest.xml` não declara permissões de armazenamento amplo nem permissões de internet, câmera, microfone, localização, contatos ou notificações. A seleção de vídeos e imagens usa o seletor de documentos do Android (`OpenDocument`), que concede acesso ao item escolhido pelo usuário. O aplicativo copia os conteúdos selecionados para o diretório privado.

## Compilação

- JDK 17, Android SDK 35 e Gradle 8.11.1.
- Abra a pasta `mytube` no Android Studio e execute `:app:assembleDebug`.
- O workflow `.github/workflows/build-apk.yml` publica o artefato `MYTUBE-2.2-APK`.
- APK esperado: `app/build/outputs/apk/debug/app-debug.apk`.

## Validação

O ZIP foi atualizado e inspecionado estaticamente. A compilação Gradle e os testes em dispositivo devem ser executados no Android Studio ou GitHub Actions.
