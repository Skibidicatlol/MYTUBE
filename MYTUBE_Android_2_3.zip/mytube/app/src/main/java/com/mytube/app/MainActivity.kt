package com.mytube.app

import android.app.Activity
import android.content.Context
import android.provider.OpenableColumns
import androidx.compose.foundation.combinedClickable
import androidx.compose.material.icons.filled.Close
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import org.json.JSONArray
import org.json.JSONObject
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.FullscreenExit
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LibraryBooks
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.WatchLater
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.QueueMusic
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalConfiguration
import android.content.res.Configuration
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.produceState
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.File
import java.io.FileOutputStream
import java.util.UUID
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import android.media.MediaMetadataRetriever
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private data class MyTubePalette(
    val background: Color, val surface: Color, val text: Color, val muted: Color, val accent: Color,
    val chip: Color, val onChip: Color
)
private val DarkPalette = MyTubePalette(Color(0xFF0B0B0B), Color(0xFF191919), Color(0xFFF5F5F5), Color(0xFFAAAAAA), Color(0xFFFF0033), Color(0xFF292929), Color.White)
private val LightPalette = MyTubePalette(Color(0xFFF6F6F8), Color(0xFFFFFFFF), Color(0xFF171717), Color(0xFF666666), Color(0xFFD9002B), Color(0xFFEAEAF0), Color(0xFF171717))
private val LocalMyTubePalette = staticCompositionLocalOf { DarkPalette }
private val Bg: Color @Composable get() = LocalMyTubePalette.current.background
private val SurfaceDark: Color @Composable get() = LocalMyTubePalette.current.surface
private val TextMain: Color @Composable get() = LocalMyTubePalette.current.text
private val TextMuted: Color @Composable get() = LocalMyTubePalette.current.muted
private val Accent: Color @Composable get() = LocalMyTubePalette.current.accent

private data class LocalVideo(val uri: String, val name: String, val isShort: Boolean, val thumbnailPath: String? = null)
private data class LocalPlaylist(val id: String, val name: String, val description: String, val videoUris: List<String>, val coverUri: String? = null, val coverImagePath: String? = null)
private enum class Tab(val label: String) { HOME("Início"), SHORTS("Shorts"), UPLOAD("Enviar"), YOU("Você") }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MyTubeApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MyTubeApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("mytube_library", Context.MODE_PRIVATE) }
    var themeMode by remember { mutableStateOf(prefs.getString("theme_mode", "dark") ?: "dark") }
    val systemDark = isSystemInDarkTheme()
    val useDarkTheme = themeMode == "dark" || (themeMode == "system" && systemDark)
    val appPalette = if (useDarkTheme) DarkPalette else LightPalette
    var videos by remember {
        mutableStateOf(loadVideos(prefs).map { v ->
            if (v.name.all { it.isDigit() }) v.copy(name = queryDisplayName(context, Uri.parse(v.uri))) else v
        })
    }
    var selectedTab by remember { mutableStateOf(Tab.HOME) }
    var secondaryPage by rememberSaveable { mutableStateOf<String?>(null) }
    var selectedVideoUri by rememberSaveable { mutableStateOf<String?>(null) }
    var selectedShortUri by rememberSaveable { mutableStateOf<String?>(null) }
    var activeQueueUris by remember { mutableStateOf<List<String>>(emptyList()) }
    var previousVideoUri by remember { mutableStateOf<String?>(null) }
    var searchText by rememberSaveable { mutableStateOf("") }
    var searchActive by rememberSaveable { mutableStateOf(false) }
    var videoToRemove by remember { mutableStateOf<LocalVideo?>(null) }
    val selectedVideo = videos.firstOrNull { it.uri == selectedVideoUri }
    var importAsShort by remember { mutableStateOf(false) }
    var isImporting by remember { mutableStateOf(false) }
    var importError by remember { mutableStateOf<String?>(null) }
    val importScope = rememberCoroutineScope()

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null && !isImporting) {
            val shortChoice = importAsShort
            val displayName = queryDisplayName(context, uri)
            importError = null
            isImporting = true
            importScope.launch {
                try {
                    val copiedUri = withContext(Dispatchers.IO) { copyVideoToPrivateStorage(context, uri, displayName) }
                    val item = LocalVideo(copiedUri.toString(), displayName, shortChoice)
                    videos = (videos.filterNot { it.name == item.name && it.isShort == item.isShort } + item)
                    saveVideos(prefs, videos)
                    if (shortChoice) { selectedTab = Tab.SHORTS; selectedShortUri = copiedUri.toString() } else selectedTab = Tab.HOME
                } catch (e: Exception) {
                    importError = "Não foi possível importar esse vídeo. Verifique se o arquivo está acessível e tente novamente."
                } finally {
                    isImporting = false
                }
            }
        }
    }

    videoToRemove?.let { target ->
        AlertDialog(
            onDismissRequest = { videoToRemove = null },
            title = { Text("Remover da biblioteca?") },
            text = { Text("“${target.name}” sai do MYTUBE. O arquivo original no celular não é apagado.") },
            confirmButton = {
                TextButton(onClick = {
                    deletePrivateVideoIfOwned(context, target.uri)
                    prefs.getString("thumbnail_${target.uri.hashCode()}", null)?.let { try { File(it).delete() } catch (_: Exception) { } }
                    prefs.edit().remove("thumbnail_${target.uri.hashCode()}").apply()
                    try { context.contentResolver.releasePersistableUriPermission(Uri.parse(target.uri), android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
                    val likedAfterDelete = prefs.getStringSet("liked_video_uris", emptySet()).orEmpty().toMutableSet().apply { remove(target.uri) }
                    val laterAfterDelete = prefs.getStringSet("watch_later_uris", emptySet()).orEmpty().toMutableSet().apply { remove(target.uri) }
                    prefs.edit().remove(progressKey(target.uri)).remove("last_watched_${target.uri.hashCode()}")
                        .putStringSet("liked_video_uris", likedAfterDelete).putStringSet("watch_later_uris", laterAfterDelete).apply()
                    val cleanedPlaylists = loadPlaylists(prefs).map { it.copy(videoUris = it.videoUris.filterNot { uri -> uri == target.uri }, coverUri = if (it.coverUri == target.uri) null else it.coverUri) }
                    savePlaylists(prefs, cleanedPlaylists)
                    videos = videos.filterNot { it.uri == target.uri }
                    saveVideos(prefs, videos)
                    videoToRemove = null
                }) { Text("Remover", color = Accent) }
            },
            dismissButton = { TextButton(onClick = { videoToRemove = null }) { Text("Cancelar") } }
        )
    }

    CompositionLocalProvider(LocalMyTubePalette provides appPalette) {
    MaterialTheme(colorScheme = if (useDarkTheme) darkColorScheme(
        background = appPalette.background, surface = appPalette.surface, primary = appPalette.accent,
        onBackground = appPalette.text, onSurface = appPalette.text
    ) else lightColorScheme(
        background = appPalette.background, surface = appPalette.surface, primary = appPalette.accent,
        onBackground = appPalette.text, onSurface = appPalette.text
    )) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            if (secondaryPage != null) {
                when (secondaryPage) {
                    "channel" -> LocalChannelScreen(
                        videos = videos, prefs = prefs,
                        onVideo = { selectedVideoUri = it.uri; secondaryPage = null },
                        onShort = { selectedShortUri = it.uri; secondaryPage = null },
                        onBack = { secondaryPage = null }
                    )
                    "settings" -> StageSettingsScreen(
                        prefs = prefs, videos = videos, themeMode = themeMode,
                        onThemeChange = { themeMode = it; prefs.edit().putString("theme_mode", it).apply() },
                        onOpenProfile = { secondaryPage = null; selectedTab = Tab.YOU },
                        onBack = { secondaryPage = null }
                    )
                }
            } else if (selectedShortUri != null) {
                ShortsPlayerScreen(
                    shorts = videos.filter { it.isShort },
                    startUri = selectedShortUri!!,
                    onBack = { selectedShortUri = null }
                )
            } else if (selectedVideo != null) {
                VideoPlayerScreen(
                    video = selectedVideo,
                    allVideos = videos.filter { !it.isShort },
                    queueVideos = if (activeQueueUris.isNotEmpty()) activeQueueUris.mapNotNull { u -> videos.firstOrNull { it.uri == u && !it.isShort } } else emptyList(),
                    previousVideoUri = previousVideoUri,
                    prefs = prefs,
                    onBack = { selectedVideoUri = null; activeQueueUris = emptyList(); previousVideoUri = null },
                    onNextVideo = { nextUri -> previousVideoUri = selectedVideoUri; selectedVideoUri = nextUri },
                    onQueueChange = { activeQueueUris = it }
                )
            } else {
                Scaffold(
                    containerColor = Bg,
                    topBar = {
                        if (selectedTab != Tab.UPLOAD && selectedTab != Tab.YOU) {
                            TopAppBar(
                                title = {
                                    if (searchActive) {
                                        val focus = remember { FocusRequester() }
                                        LaunchedEffect(Unit) { try { focus.requestFocus() } catch (_: Exception) { } }
                                        TextField(
                                            value = searchText,
                                            onValueChange = { searchText = it },
                                            placeholder = { Text("Pesquisar vídeos", color = TextMuted) },
                                            singleLine = true,
                                            colors = TextFieldDefaults.colors(
                                                focusedContainerColor = SurfaceDark, unfocusedContainerColor = SurfaceDark,
                                                focusedTextColor = TextMain, unfocusedTextColor = TextMain,
                                                focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
                                                cursorColor = Accent
                                            ),
                                            modifier = Modifier.fillMaxWidth().focusRequester(focus)
                                        )
                                    } else Brand()
                                },
                                actions = {
                                    IconButton(onClick = { if (searchActive) searchText = ""; searchActive = !searchActive }) {
                                        Icon(if (searchActive) Icons.Default.Close else Icons.Default.Search, "Pesquisar", tint = TextMain)
                                    }
                                    if (!searchActive && selectedTab == Tab.HOME) {
                                        IconButton(onClick = { secondaryPage = "channel" }) {
                                            Icon(Icons.Default.Person, "Canal", tint = TextMain)
                                        }
                                        IconButton(onClick = { secondaryPage = "settings" }) {
                                            Icon(Icons.Default.Settings, "Configurações", tint = TextMain)
                                        }
                                    }
                                },
                                colors = TopAppBarDefaults.topAppBarColors(containerColor = Bg)
                            )
                        }
                    },
                    bottomBar = {
                        NavigationBar(containerColor = Bg, contentColor = TextMain) {
                            listOf(Tab.HOME, Tab.SHORTS, Tab.UPLOAD, Tab.YOU).forEach { tab ->
                                NavigationBarItem(
                                    selected = selectedTab == tab,
                                    onClick = {
                                        if (tab == Tab.UPLOAD) {
                                            importAsShort = false
                                            selectedTab = Tab.UPLOAD
                                        } else if (tab == Tab.SHORTS) {
                                            selectedTab = Tab.SHORTS
                                            val available = videos.filter { it.isShort }
                                            if (available.isNotEmpty()) selectedShortUri = available.random().uri
                                        } else selectedTab = tab
                                    },
                                    icon = {
                                        when (tab) {
                                            Tab.HOME -> Icon(Icons.Default.Home, null)
                                            Tab.SHORTS -> Icon(Icons.Default.PlayArrow, null)
                                            Tab.UPLOAD -> Icon(Icons.Default.Add, null)
                                            Tab.YOU -> Icon(Icons.Default.Person, null)
                                        }
                                    },
                                    label = { Text(tab.label, fontSize = 10.sp) },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = TextMain,
                                        selectedTextColor = TextMain,
                                        indicatorColor = SurfaceDark,
                                        unselectedIconColor = TextMuted,
                                        unselectedTextColor = TextMuted
                                    )
                                )
                            }
                        }
                    }
                ) { padding ->
                    Box(Modifier.padding(padding).fillMaxSize()) {
                        when (selectedTab) {
                            Tab.HOME -> HomeScreen(
                                videos = videos.filter { !searchActive || searchText.isBlank() || it.name.contains(searchText.trim(), true) },
                                query = if (searchActive) searchText else "",
                                prefs = prefs,
                                shorts = videos.filter { it.isShort },
                                onVideo = { activeQueueUris = emptyList(); previousVideoUri = null; selectedVideoUri = it.uri },
                                onShort = { selectedShortUri = it.uri },
                                onRemove = { videoToRemove = it }
                            )
                            Tab.SHORTS -> ShortsScreen(
                                videos.filter { it.isShort && (!searchActive || searchText.isBlank() || it.name.contains(searchText.trim(), true)) },
                                onVideo = { selectedShortUri = it.uri },
                                onRemove = { videoToRemove = it }
                            )
                            Tab.UPLOAD -> UploadScreen(isImporting, importError, onPick = { asShort -> importAsShort = asShort; picker.launch(arrayOf("video/*")) })
                            Tab.YOU -> LibraryScreen(
                                videos = videos, prefs = prefs,
                                onVideo = { activeQueueUris = emptyList(); previousVideoUri = null; selectedVideoUri = it.uri },
                                onShort = { selectedShortUri = it.uri },
                                onRemove = { videoToRemove = it },
                                onOpenChannel = { secondaryPage = "channel" },
                                onPlayPlaylist = { playlist, startUri ->
                                    activeQueueUris = playlist.videoUris
                                    previousVideoUri = null
                                    selectedVideoUri = startUri ?: playlist.videoUris.firstOrNull()
                                }
                            )
                        }
                    }
                }
            }
        }
    }
    }
}

@Composable
private fun LocalChannelScreen(
    videos: List<LocalVideo>,
    prefs: android.content.SharedPreferences,
    onVideo: (LocalVideo) -> Unit,
    onShort: (LocalVideo) -> Unit,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)
    Column(Modifier.fillMaxSize().background(Bg)) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Voltar", tint = TextMain) }
            Text("Canal", color = TextMain, fontSize = 21.sp, fontWeight = FontWeight.Bold)
        }
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            val channelAvatar = remember { try { prefs.getString("profile_photo_path", null)?.let { BitmapFactory.decodeFile(it) } } catch (_: Exception) { null } }
            Box(Modifier.size(64.dp).clip(CircleShape).background(SurfaceDark), contentAlignment = Alignment.Center) {
                if (channelAvatar != null) Image(channelAvatar.asImageBitmap(), contentDescription = "Foto do canal", modifier = Modifier.fillMaxSize(), contentScale = androidx.compose.ui.layout.ContentScale.Crop)
                else Icon(Icons.Default.Person, null, tint = TextMain, modifier = Modifier.size(38.dp))
            }
            Column(Modifier.padding(start = 14.dp)) {
                Text(prefs.getString("profile_name", "Meu perfil") ?: "Meu perfil", color = TextMain, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text(prefs.getString("profile_handle", "@meuperfil") ?: "@meuperfil", color = TextMuted, fontSize = 12.sp)
                val description = prefs.getString("profile_description", "").orEmpty()
                if (description.isNotBlank()) Text(description, color = TextMuted, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text("Canal local · somente neste dispositivo", color = TextMuted, fontSize = 11.sp)
            }
        }
        Text("${videos.count { !it.isShort }} vídeos · ${videos.count { it.isShort }} Shorts",
            color = TextMuted, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp))
        if (videos.isEmpty()) {
            EmptyScreen("Seu canal está vazio", "Os vídeos e Shorts importados aparecerão aqui.", Icons.Default.VideoLibrary)
        } else {
            LazyColumn {
                if (videos.any { !it.isShort }) {
                    item { Text("Vídeos", color = TextMain, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(16.dp)) }
                    items(videos.filter { !it.isShort }, key = { "channel_video_${it.uri}" }) { v ->
                        VideoRow(v, onClick = { onVideo(v) })
                    }
                }
                if (videos.any { it.isShort }) {
                    item { Text("Shorts", color = TextMain, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(16.dp)) }
                    items(videos.filter { it.isShort }, key = { "channel_short_${it.uri}" }) { v ->
                        VideoRow(v, onClick = { onShort(v) })
                    }
                }
            }
        }
    }
}

@Composable
private fun StageSettingsScreen(
    prefs: android.content.SharedPreferences,
    videos: List<LocalVideo>,
    themeMode: String,
    onThemeChange: (String) -> Unit,
    onOpenProfile: () -> Unit,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)
    val settingsContext = LocalContext.current
    var autoplay by remember { mutableStateOf(prefs.getBoolean("autoplay", true)) }
    var repeatVideo by remember { mutableStateOf(prefs.getBoolean("repeat_video", false)) }
    var repeatPlaylist by remember { mutableStateOf(prefs.getBoolean("repeat_playlist", false)) }
    var shuffleEnabled by remember { mutableStateOf(prefs.getBoolean("shuffle_enabled", false)) }
    var showShortsHome by remember { mutableStateOf(prefs.getBoolean("show_shorts_home", true)) }
    var section by rememberSaveable { mutableStateOf("Principal") }
    val storageBytes = remember(videos) {
        videos.sumOf { item -> try { File(Uri.parse(item.uri).path ?: "").length() } catch (_: Exception) { 0L } } +
            contextCacheSize(File(settingsContext.filesDir, "thumbnails")) +
            contextCacheSize(File(settingsContext.filesDir, "playlist_covers")) +
            contextCacheSize(File(settingsContext.filesDir, "profile"))
    }
    var cacheBytes by remember { mutableLongStateOf(contextCacheSize(settingsContext.cacheDir)) }
    Column(Modifier.fillMaxSize().background(Bg)) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Voltar", tint = TextMain) }
            Text("Configurações", color = TextMain, fontSize = 21.sp, fontWeight = FontWeight.Bold)
        }
        Row(Modifier.fillMaxWidth().horizontalScroll(androidx.compose.foundation.rememberScrollState()).padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Principal", "Conta", "Aparência", "Reprodução", "Recomendações", "Armazenamento", "Privacidade", "Sobre", "Direitos", "Como funciona", "Ajuda").forEach {
                FilterChip(selected = section == it, onClick = { section = it }, label = { Text(it) })
            }
        }
        when (section) {
            "Conta" -> Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Conta local", color = TextMain, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text(prefs.getString("profile_name", "Meu perfil") ?: "Meu perfil", color = TextMain, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                Text(prefs.getString("profile_handle", "@meuperfil") ?: "@meuperfil", color = TextMuted)
                Text("Perfil armazenado somente neste dispositivo.", color = TextMuted, fontSize = 13.sp)
                Button(onClick = onOpenProfile, colors = ButtonDefaults.buttonColors(containerColor = Accent)) { Icon(Icons.Default.Person, null); Spacer(Modifier.width(6.dp)); Text("Abrir meu perfil") }
            }
            "Aparência" -> Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Aparência", color = TextMain, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                listOf("dark" to "Escuro", "light" to "Claro", "system" to "Automático (Android)").forEach { (value, label) ->
                    Row(Modifier.fillMaxWidth().clickable { onThemeChange(value) }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = themeMode == value, onClick = { onThemeChange(value) })
                        Text(label, color = TextMain, modifier = Modifier.padding(start = 8.dp))
                    }
                }
                Text("A preferência é salva neste dispositivo.", color = TextMuted, fontSize = 12.sp)
            }
            "Reprodução" -> Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text("Reprodução", color = TextMain, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                SettingSwitch("Reprodução automática", "Avançar para outro vídeo ao terminar", autoplay) { autoplay = it; prefs.edit().putBoolean("autoplay", it).apply() }
                SettingSwitch("Repetir vídeo atual", "Recomeçar o vídeo ao chegar ao fim", repeatVideo) { repeatVideo = it; prefs.edit().putBoolean("repeat_video", it).apply() }
                SettingSwitch("Repetir playlist", "Recomeçar a fila quando chegar ao final", repeatPlaylist) { repeatPlaylist = it; prefs.edit().putBoolean("repeat_playlist", it).apply() }
                SettingSwitch("Reprodução aleatória", "Escolher o próximo vídeo aleatoriamente", shuffleEnabled) { shuffleEnabled = it; prefs.edit().putBoolean("shuffle_enabled", it).apply() }
            }
            "Recomendações" -> {
                val categories = listOf("Jogos", "Música", "Esportes", "Tecnologia", "Educação", "Comédia", "Entretenimento", "Outros")
                var preferred by remember { mutableStateOf(prefs.getStringSet("preferred_video_categories", emptySet()).orEmpty().toSet()) }
                Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Preferências de recomendações", color = TextMain, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("Escolha categorias que devem receber prioridade. A seleção fica salva somente neste dispositivo.", color = TextMuted, fontSize = 13.sp)
                    categories.forEach { category ->
                        Row(Modifier.fillMaxWidth().clickable {
                            preferred = if (category in preferred) preferred - category else preferred + category
                            prefs.edit().putStringSet("preferred_video_categories", preferred).apply()
                        }.padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = category in preferred, onCheckedChange = { checked ->
                                preferred = if (checked) preferred + category else preferred - category
                                prefs.edit().putStringSet("preferred_video_categories", preferred).apply()
                            })
                            Text(category, color = TextMain)
                        }
                    }
                    Text("As categorias dos vídeos são estimadas pelo título; você pode ajustar o nome do arquivo para melhorar a classificação.", color = TextMuted, fontSize = 12.sp)
                }
            }
            "Armazenamento" -> Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Armazenamento", color = TextMain, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text("Vídeos e Shorts: ${formatBytes(storageBytes)}", color = TextMain)
                Text("Arquivos na biblioteca: ${videos.size}", color = TextMain)
                Text("Cache: ${formatBytes(cacheBytes)}", color = TextMain)
                Button(onClick = { settingsContext.cacheDir.deleteRecursively(); settingsContext.cacheDir.mkdirs(); cacheBytes = contextCacheSize(settingsContext.cacheDir) }, colors = ButtonDefaults.buttonColors(containerColor = Accent)) { Icon(Icons.Default.DeleteForever, null); Spacer(Modifier.width(6.dp)); Text("Limpar cache") }
                Text("A limpeza remove somente arquivos temporários. Os vídeos importados não são apagados.", color = TextMuted, fontSize = 12.sp)
            }
            "Privacidade" -> InfoSettingsSection("Privacidade e permissões", listOf(
                "O MYTUBE funciona com uma conta local neste dispositivo; não exige login, servidor ou sincronização online.",
                "Vídeos: o seletor de documentos do Android (OpenDocument) permite escolher somente os arquivos que você selecionar. O aplicativo recebe acesso ao URI escolhido e copia o conteúdo para a pasta privada.",
                "Imagens e fotos: o mesmo seletor do Android é usado para escolher avatar, thumbnail ou capa. O aplicativo não solicita acesso amplo a todas as fotos.",
                "Armazenamento: os arquivos importados e as imagens escolhidas são gravados no armazenamento privado do aplicativo; não há solicitação de permissão ampla de armazenamento no Manifest.",
                "Rede/Internet: o Manifest atual não declara INTERNET. A reprodução e as recomendações são locais.",
                "Notificações, localização, câmera, microfone e contatos: não são solicitados pelo Manifest atual.",
                "Ao limpar os dados ou desinstalar o aplicativo, os dados locais podem ser perdidos."
            ))
            "Sobre" -> InfoSettingsSection("Sobre o MYTUBE", listOf("MYTUBE", "Versão 2.1", "Aplicativo pessoal para organizar e reproduzir vídeos localmente.", "Desenvolvedor: informação não fornecida."))
            "Direitos" -> InfoSettingsSection("Direitos e licenças", listOf(
                "Android Gradle Plugin 8.9.1 — ferramenta de build Android, licença Apache License 2.0.",
                "Kotlin e Kotlin Compose plugin 2.1.10 — licença Apache License 2.0.",
                "AndroidX Activity Compose 1.10.1 — Apache License 2.0.",
                "Jetpack Compose BOM 2025.02.00 e artefatos Compose UI, UI Tooling Preview, Material 3 e Material Icons Extended — Apache License 2.0.",
                "Lifecycle Runtime KTX 2.8.7 — Apache License 2.0.",
                "AndroidX Media3 ExoPlayer, Media3 UI e Media3 Common 1.5.1 — Apache License 2.0.",
                "As dependências transitivas podem incluir avisos adicionais; esta tela resume as dependências diretas declaradas no Gradle e não substitui os arquivos NOTICE/LICENSE distribuídos com cada artefato.",
                "Room e Coil não estão declarados nas dependências diretas atuais.",
                "Vídeos, imagens, músicas, marcas e outros conteúdos importados continuam pertencendo aos respectivos titulares. O usuário é responsável por possuir autorização para utilizá-los."
            ))
            "Como funciona" -> InfoSettingsSection("Como funciona o MYTUBE", listOf("Importação: use Enviar para selecionar um vídeo ou importá-lo como Short.", "Armazenamento: o MYTUBE copia o conteúdo para a pasta privada do aplicativo.", "Playlists: crie e organize coleções locais na página Você.", "Shorts: abra a aba Shorts para reprodução automática e navegação vertical.", "Conta: o perfil e as preferências ficam salvos localmente no dispositivo."))
            "Ajuda" -> InfoSettingsSection("Ajuda e perguntas frequentes", listOf("Como importar? Abra Enviar e selecione um vídeo.", "Onde os vídeos ficam? Em uma pasta privada do aplicativo.", "Como criar uma playlist? Abra Você > Playlists > Criar playlist.", "Como usar Shorts? Abra a aba Shorts e deslize verticalmente.", "Como liberar espaço? Remova vídeos da biblioteca ou limpe somente o cache nas configurações."))
            else -> Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text("MYTUBE 2.1", color = TextMain, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("Configurações do aplicativo", color = TextMuted)
                SettingSwitch("Mostrar Shorts no Início", "Exibir a prateleira horizontal de Shorts", showShortsHome) { showShortsHome = it; prefs.edit().putBoolean("show_shorts_home", it).apply() }
                Text("Conta local · funcionamento offline · armazenamento privado", color = TextMuted, fontSize = 13.sp)
            }
        }
    }
}

@Composable
private fun SettingSwitch(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) { Text(title, color = TextMain, fontWeight = FontWeight.Medium); Text(subtitle, color = TextMuted, fontSize = 12.sp) }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun InfoSettingsSection(title: String, lines: List<String>) {
    Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(title, color = TextMain, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        lines.forEach { Text("• $it", color = TextMuted, fontSize = 14.sp) }
    }
}

private fun contextCacheSize(dir: File): Long = try { dir.walkTopDown().filter { it.isFile }.sumOf { it.length() } } catch (_: Exception) { 0L }
private fun formatBytes(bytes: Long): String {
    if (bytes < 1024) return "$bytes B"
    val kb = bytes / 1024.0
    if (kb < 1024) return String.format(java.util.Locale.US, "%.1f KB", kb)
    val mb = kb / 1024.0
    if (mb < 1024) return String.format(java.util.Locale.US, "%.1f MB", mb)
    return String.format(java.util.Locale.US, "%.2f GB", mb / 1024.0)
}

@Composable
private fun Brand() {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Box(Modifier.size(width = 34.dp, height = 24.dp).clip(RoundedCornerShape(7.dp)).background(Accent), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.PlayArrow, null, tint = Color.White, modifier = Modifier.size(22.dp))
        }
        Text("MYTUBE", color = TextMain, fontWeight = FontWeight.Black, fontSize = 21.sp, letterSpacing = (-0.7).sp)
    }
}

@Composable
private fun HomeScreen(
    videos: List<LocalVideo>,
    query: String,
    prefs: android.content.SharedPreferences,
    shorts: List<LocalVideo>,
    onVideo: (LocalVideo) -> Unit,
    onShort: (LocalVideo) -> Unit,
    onRemove: (LocalVideo) -> Unit
) {
    var category by remember { mutableStateOf("Todos") }
    val categories = listOf("Todos", "Jogos", "Música", "Minecraft", "Roblox")
    val searched = videos.filter { !it.isShort && (query.isBlank() || it.name.contains(query.trim(), true)) }
    val visible = searched.filter { video ->
        when (category) {
            "Minecraft" -> video.name.contains("minecraft", true)
            "Roblox" -> video.name.contains("roblox", true)
            "Música" -> listOf("música", "musica", "music", "song").any { video.name.contains(it, true) }
            "Jogos" -> listOf("game", "jogo", "minecraft", "roblox", "gta", "fortnite").any { video.name.contains(it, true) }
            else -> true
        }
    }
    val likedUris = prefs.getStringSet("liked_video_uris", emptySet()).orEmpty()
    val laterUris = prefs.getStringSet("watch_later_uris", emptySet()).orEmpty()
    val preferredCategories = prefs.getStringSet("preferred_video_categories", emptySet()).orEmpty()
    val likedCategories = videos.filter { it.uri in likedUris }.map { inferVideoCategory(it.name) }.toSet()
    val historyUris = visible.filter { prefs.getLong("last_watched_${it.uri.hashCode()}", 0L) > 0L }.map { it.uri }.toSet()
    val recommended = visible.sortedByDescending { candidate ->
        val name = candidate.name.lowercase()
        val categoryName = inferVideoCategory(candidate.name)
        val recent = if (prefs.getLong("last_watched_${candidate.uri.hashCode()}", 0L) > 0L) 10_000L else 0L
        val likedBonus = if (candidate.uri in likedUris) 100_000L else 0L
        val savedBonus = if (candidate.uri in laterUris) 20_000L else 0L
        val preferredBonus = if (categoryName in preferredCategories) 50_000L else 0L
        val likedCategoryBonus = if (categoryName in likedCategories) 30_000L else 0L
        val titleSimilarity = videos.filter { it.uri in likedUris }.sumOf { liked ->
            val words = liked.name.lowercase().split(Regex("\\W+")).filter { it.length > 3 }.toSet()
            name.split(Regex("\\W+")).count { it in words }.toLong() * 100L
        }
        recent + likedBonus + savedBonus + preferredBonus + likedCategoryBonus + titleSimilarity
    }
    val showShortsShelf = prefs.getBoolean("show_shorts_home", true)
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 18.dp)) {
        item {
            Row(
                Modifier.fillMaxWidth()
                    .horizontalScroll(androidx.compose.foundation.rememberScrollState())
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                categories.forEach { label ->
                    Surface(
                        color = if (category == label) Color.White else SurfaceDark,
                        shape = RoundedCornerShape(9.dp),
                        modifier = Modifier.clickable { category = label }
                    ) {
                        Text(label, color = if (category == label) Color.Black else TextMain,
                            modifier = Modifier.padding(horizontal = 13.dp, vertical = 8.dp),
                            fontSize = 13.sp, fontWeight = FontWeight.Medium, maxLines = 1, softWrap = false)
                    }
                }
            }
        }
        if (shorts.isNotEmpty() && query.isBlank() && showShortsShelf) {
            item {
                Text("Shorts", color = TextMain, fontSize = 18.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(start = 14.dp, top = 14.dp, bottom = 8.dp))
                androidx.compose.foundation.lazy.LazyRow(
                    contentPadding = PaddingValues(horizontal = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(shorts, key = { "home_short_${it.uri}" }) { short ->
                        Column(
                            Modifier.width(124.dp).clickable { onShort(short) }
                        ) {
                            Box(
                                Modifier.fillMaxWidth().height(190.dp).clip(RoundedCornerShape(12.dp))
                                    .background(SurfaceDark)
                            ) {
                                VideoThumbnail(short.uri, Modifier.fillMaxSize())
                                Box(Modifier.align(Alignment.BottomStart).fillMaxWidth()
                                    .background(Color.Black.copy(alpha = 0.55f)).padding(7.dp)) {
                                    Text(short.name, color = Color.White, fontSize = 12.sp,
                                        maxLines = 2, overflow = TextOverflow.Ellipsis)
                                }
                            }
                            ThumbnailEditor(short, compact = true)
                        }
                    }
                }
            }
        }
        if (visible.isEmpty()) {
            item { WelcomeCard() }
        } else {
            item {
                Text("Recomendados para você", color = TextMain, fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(start = 14.dp, top = 14.dp, bottom = 8.dp))
            }
            items(recommended, key = { "video_${it.uri}" }) { video ->
                VideoRow(video, onClick = { onVideo(video) }, onLongClick = { onRemove(video) })
            }
        }
    }
}

@Composable
private fun WelcomeCard() {
    Column(Modifier.fillMaxWidth().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Box(Modifier.size(76.dp).clip(CircleShape).background(SurfaceDark), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.VideoLibrary, null, tint = Accent, modifier = Modifier.size(38.dp))
        }
        Text("Sua página inicial", color = TextMain, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text("Importe vídeos do seu celular para começar sua biblioteca. Eles ficam disponíveis offline.", color = TextMuted, fontSize = 14.sp)
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun VideoRow(video: LocalVideo, onClick: () -> Unit, onLongClick: () -> Unit = {}) {
    Row(
        Modifier.fillMaxWidth().combinedClickable(onClick = onClick, onLongClick = onLongClick)
            .padding(horizontal = 12.dp, vertical = 7.dp),
        verticalAlignment = Alignment.Top
    ) {
        Box(Modifier.width(148.dp).aspectRatio(16f / 9f).clip(RoundedCornerShape(10.dp)).background(Color(0xFF242424))) {
            VideoThumbnail(video.uri, Modifier.fillMaxSize())
        }
        Column(Modifier.weight(1f).padding(start = 12.dp)) {
            Text(video.name, color = TextMain, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(3.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Sua biblioteca", color = TextMuted, fontSize = 12.sp)
                Spacer(Modifier.width(6.dp))
                VideoDurationText(video.uri)
            }
            ThumbnailEditor(video, compact = true)
        }
    }
}

@Composable
private fun VideoDurationText(uri: String) {
    val context = LocalContext.current
    val duration by produceState<String?>(initialValue = null, key1 = uri) {
        value = withContext(Dispatchers.IO) {
            val retriever = MediaMetadataRetriever()
            try {
                retriever.setDataSource(context, Uri.parse(uri))
                val ms = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                if (ms <= 0L) null else {
                    val total = ms / 1000L
                    val h = total / 3600L
                    val m = (total % 3600L) / 60L
                    val sec = total % 60L
                    if (h > 0) String.format(java.util.Locale.US, "%d:%02d:%02d", h, m, sec) else String.format(java.util.Locale.US, "%d:%02d", m, sec)
                }
            } catch (_: Exception) { null } finally { try { retriever.release() } catch (_: Exception) { } }
        }
    }
    if (duration != null) Text("· $duration", color = TextMuted, fontSize = 11.sp)
}

@Composable
private fun VideoThumbnail(uri: String, modifier: Modifier = Modifier, customPath: String? = null) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("mytube_library", Context.MODE_PRIVATE) }
    var storedPath by remember(uri, customPath) { mutableStateOf(customPath ?: prefs.getString("thumbnail_${uri.hashCode()}", null)) }
    DisposableEffect(prefs, uri) {
        val listener = android.content.SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
            if (key == "thumbnail_${uri.hashCode()}") storedPath = prefs.getString(key, null)
        }
        prefs.registerOnSharedPreferenceChangeListener(listener)
        onDispose { prefs.unregisterOnSharedPreferenceChangeListener(listener) }
    }
    val bitmap by produceState<Bitmap?>(initialValue = null, key1 = uri, key2 = storedPath) {
        value = withContext(Dispatchers.IO) {
            if (!storedPath.isNullOrBlank()) {
                try { BitmapFactory.decodeFile(storedPath) } catch (_: Exception) { null }
            } else {
                val retriever = MediaMetadataRetriever()
                try {
                    retriever.setDataSource(context, Uri.parse(uri))
                    retriever.getFrameAtTime(1_000_000L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                } catch (_: Exception) { null }
                finally { try { retriever.release() } catch (_: Exception) { } }
            }
        }
    }
    if (bitmap != null) {
        Image(bitmap = bitmap!!.asImageBitmap(), contentDescription = "Miniatura personalizada", modifier = modifier,
            contentScale = androidx.compose.ui.layout.ContentScale.Crop)
    } else {
        Box(modifier, contentAlignment = Alignment.Center) {
            Icon(Icons.Default.VideoLibrary, null, tint = TextMuted, modifier = Modifier.size(48.dp))
        }
    }
}

@Composable
private fun ThumbnailEditor(video: LocalVideo, compact: Boolean = false) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("mytube_library", Context.MODE_PRIVATE) }
    val scope = rememberCoroutineScope()
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) scope.launch {
            val saved = withContext(Dispatchers.IO) {
                try {
                    val dir = File(context.filesDir, "thumbnails").apply { if (!exists()) mkdirs() }
                    val target = File(dir, "thumb_${video.uri.hashCode()}_${System.currentTimeMillis()}.img")
                    context.contentResolver.openInputStream(uri)?.use { input -> FileOutputStream(target).use { output -> input.copyTo(output); output.fd.sync() } }
                    if (target.exists() && target.length() > 0) target.absolutePath else null
                } catch (_: Exception) { null }
            }
            if (saved != null) {
                val old = prefs.getString("thumbnail_${video.uri.hashCode()}", null)
                prefs.edit().putString("thumbnail_${video.uri.hashCode()}", saved).apply()
                if (old != null && old != saved) try { File(old).delete() } catch (_: Exception) { }
            }
        }
    }
    val current = prefs.getString("thumbnail_${video.uri.hashCode()}", null)
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.End, modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp)) {
        TextButton(onClick = { picker.launch(arrayOf("image/*")) }) { Text(if (compact) "Editar capa" else "Editar thumbnail", color = Accent, fontSize = 12.sp) }
        if (current != null) TextButton(onClick = {
            prefs.edit().remove("thumbnail_${video.uri.hashCode()}").apply()
            try { File(current).delete() } catch (_: Exception) { }
        }) { Text("Restaurar", color = TextMuted, fontSize = 12.sp) }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ShortsScreen(shorts: List<LocalVideo>, onVideo: (LocalVideo) -> Unit, onRemove: (LocalVideo) -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.PlayArrow, tint = Accent, contentDescription = null, modifier = Modifier.size(28.dp))
            Text("Shorts", color = TextMain, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
        if (shorts.isEmpty()) {
            EmptyScreen("Seus Shorts", "Os Shorts importados pela página Enviar aparecerão aqui.", Icons.Default.PlayArrow)
        } else {
            LazyColumn(contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(shorts, key = { it.uri }) { video ->
                    Box(
                        Modifier.fillMaxWidth().height(390.dp).clip(RoundedCornerShape(16.dp))
                            .background(Color(0xFF252525)).combinedClickable(onClick = { onVideo(video) }, onLongClick = { onRemove(video) }),
                        contentAlignment = Alignment.Center
                    ) {
                        VideoThumbnail(video.uri, Modifier.fillMaxSize())
                        Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.18f)))
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(Modifier.size(58.dp).clip(CircleShape).background(Color.Black.copy(alpha = 0.55f)), contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.PlayArrow, null, tint = Color.White, modifier = Modifier.size(42.dp))
                            }
                            Text(video.name, color = Color.White, fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.padding(12.dp), maxLines = 2, overflow = TextOverflow.Ellipsis)
                            Text("Toque para assistir", color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp)
                        }
                    }
                    ThumbnailEditor(video, compact = true)
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ShortsPlayerScreen(shorts: List<LocalVideo>, startUri: String, onBack: () -> Unit) {
    if (shorts.isEmpty()) {
        EmptyScreen("Nenhum Short disponível", "Adicione um vídeo curto pela aba Enviar.", Icons.Default.PlayArrow)
        return
    }
    val orderedShorts = remember(shorts, startUri) {
        val first = shorts.firstOrNull { it.uri == startUri } ?: shorts.random()
        val sequence = mutableListOf(first)
        while (sequence.size < 1000) {
            val candidates = shorts.filter { it.uri != sequence.last().uri }
            sequence += (candidates.ifEmpty { shorts }).random()
        }
        sequence
    }
    val pagerState = rememberPagerState(initialPage = 0, pageCount = { orderedShorts.size })
    BackHandler(onBack = onBack)
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        VerticalPager(state = pagerState, modifier = Modifier.fillMaxSize(), key = { page -> page }) { page ->
            ShortVideoPage(video = orderedShorts[page], active = pagerState.currentPage == page)
        }
        Row(Modifier.align(Alignment.TopStart).fillMaxWidth().background(Color.Black.copy(alpha = 0.28f)).statusBarsPadding().padding(horizontal = 8.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Voltar", tint = Color.White) }
            Text("Shorts", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            Text("${pagerState.currentPage + 1}/${orderedShorts.size}", color = Color.White.copy(alpha = 0.85f), fontSize = 12.sp, modifier = Modifier.padding(end = 12.dp))
        }
        Column(Modifier.align(Alignment.BottomStart).fillMaxWidth().background(Color.Black.copy(alpha = 0.38f)).navigationBarsPadding().padding(horizontal = 18.dp, vertical = 20.dp)) {
            val context = LocalContext.current
            val localPrefs = remember(context) { context.getSharedPreferences("mytube_library", Context.MODE_PRIVATE) }
            val creator: String = localPrefs.getString("profile_name", "Meu perfil") ?: "Meu perfil"
            val handle: String = localPrefs.getString("profile_handle", "@meuperfil") ?: "@meuperfil"
            val avatarPath: String? = localPrefs.getString("profile_photo_path", null)
            val avatar: Bitmap? = remember(avatarPath) {
                try {
                    avatarPath?.let { path -> BitmapFactory.decodeFile(path) }
                } catch (_: Exception) {
                    null
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(Modifier.size(30.dp).clip(CircleShape).background(Color.DarkGray), contentAlignment = Alignment.Center) {
                    if (avatar != null) Image(avatar.asImageBitmap(), "Foto do canal local", Modifier.fillMaxSize(), contentScale = androidx.compose.ui.layout.ContentScale.Crop)
                    else Icon(Icons.Default.Person, null, tint = Color.White, modifier = Modifier.size(20.dp))
                }
                Text("$creator · $handle", color = Color.White.copy(alpha = 0.9f), fontSize = 12.sp)
            }
            Text(orderedShorts[pagerState.currentPage].name, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 5.dp))
            Text("Vídeo local · Deslize para cima para ver outro Short", color = Color.White.copy(alpha = 0.78f), fontSize = 12.sp, modifier = Modifier.padding(top = 3.dp))
            ThumbnailEditor(orderedShorts[pagerState.currentPage], compact = true)
        }
    }
}

@Composable
private fun ShortVideoPage(video: LocalVideo, active: Boolean) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val player = remember(video.uri) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(video.uri))
            repeatMode = androidx.media3.common.Player.REPEAT_MODE_ONE
            playWhenReady = false
            prepare()
        }
    }
    DisposableEffect(player, active, lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_PAUSE) player.pause()
            if (event == Lifecycle.Event.ON_RESUME && active) player.play()
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        if (active && lifecycleOwner.lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED)) player.play()
        else player.pause()
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
            player.pause()
        }
    }
    DisposableEffect(player) {
        onDispose { player.release() }
    }
    AndroidView(
        factory = { ctx -> PlayerView(ctx).apply {
            this.player = player
            useController = false
            setShutterBackgroundColor(android.graphics.Color.BLACK)
            resizeMode = androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIT
        } },
        update = { it.player = player },
        modifier = Modifier.fillMaxSize()
    )
}

@Composable
private fun UploadScreen(isImporting: Boolean, importError: String?, onPick: (Boolean) -> Unit) {
    var asShort by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(22.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(Icons.Default.Add, null, tint = Accent, modifier = Modifier.size(58.dp))
        Text("Adicionar vídeos", color = TextMain, fontSize = 23.sp, fontWeight = FontWeight.Bold)
        Text("Escolha um vídeo armazenado no seu Android.", color = TextMuted, fontSize = 14.sp)
        Spacer(Modifier.height(22.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Adicionar como Short", color = TextMain)
            Spacer(Modifier.width(10.dp))
            Switch(checked = asShort, onCheckedChange = { asShort = it }, colors = SwitchDefaults.colors(checkedTrackColor = Accent))
        }
        Spacer(Modifier.height(14.dp))
        Button(onClick = { onPick(asShort) }, enabled = !isImporting, colors = ButtonDefaults.buttonColors(containerColor = Accent), shape = RoundedCornerShape(24.dp)) {
            if (isImporting) CircularProgressIndicator(Modifier.size(18.dp), color = Color.White, strokeWidth = 2.dp)
            else Icon(Icons.Default.VideoLibrary, null)
            Spacer(Modifier.width(8.dp))
            Text(if (isImporting) "Importando vídeo..." else "Selecionar vídeo")
        }
        Text("O MYTUBE copia o vídeo para o armazenamento privado do aplicativo. O arquivo original permanece no celular.", color = TextMuted, fontSize = 11.sp, modifier = Modifier.padding(top = 16.dp))
        if (importError != null) Text(importError, color = Color(0xFFFF7777), fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp))
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun LibraryScreen(
    videos: List<LocalVideo>, prefs: android.content.SharedPreferences,
    onVideo: (LocalVideo) -> Unit, onShort: (LocalVideo) -> Unit,
    onRemove: (LocalVideo) -> Unit, onOpenChannel: () -> Unit,
    onPlayPlaylist: (LocalPlaylist, String?) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var profileName by remember { mutableStateOf(prefs.getString("profile_name", "Meu perfil") ?: "Meu perfil") }
    var profileHandle by remember { mutableStateOf(prefs.getString("profile_handle", "@meuperfil") ?: "@meuperfil") }
    var profileDescription by remember { mutableStateOf(prefs.getString("profile_description", "") ?: "") }
    var photoPath by remember { mutableStateOf(prefs.getString("profile_photo_path", null)) }
    var showEdit by remember { mutableStateOf(false) }
    var editName by remember { mutableStateOf(profileName) }
    var editHandle by remember { mutableStateOf(profileHandle) }
    var editDescription by remember { mutableStateOf(profileDescription) }
    var section by rememberSaveable { mutableStateOf("Biblioteca") }
    var refreshKey by remember { mutableIntStateOf(0) }
    var playlists by remember { mutableStateOf(loadPlaylists(prefs)) }
    var editingPlaylist by remember { mutableStateOf<LocalPlaylist?>(null) }
    var showCreate by remember { mutableStateOf(false) }
    var selectedPlaylistId by remember { mutableStateOf<String?>(null) }
    var playlistName by remember { mutableStateOf("") }
    var playlistDescription by remember { mutableStateOf("") }
    var playlistSelection by remember { mutableStateOf<Set<String>>(emptySet()) }
    var playlistCoverUri by remember { mutableStateOf<String?>(null) }
    var playlistCoverImagePath by remember { mutableStateOf<String?>(null) }
    val playlistCoverPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) scope.launch {
            val saved = withContext(Dispatchers.IO) {
                try {
                    val dir = File(context.filesDir, "playlist_covers").apply { mkdirs() }
                    val target = File(dir, "cover_${System.currentTimeMillis()}.img")
                    context.contentResolver.openInputStream(uri)?.use { input -> FileOutputStream(target).use { output -> input.copyTo(output); output.fd.sync() } }
                    if (target.exists() && target.length() > 0) target.absolutePath else null
                } catch (_: Exception) { null }
            }
            if (saved != null) playlistCoverImagePath = saved
        }
    }
    val liked = remember(refreshKey) { prefs.getStringSet("liked_video_uris", emptySet()).orEmpty().toSet() }
    val later = remember(refreshKey) { prefs.getStringSet("watch_later_uris", emptySet()).orEmpty().toSet() }
    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) scope.launch {
            val saved = withContext(Dispatchers.IO) {
                try { context.contentResolver.openInputStream(uri)?.use { input ->
                    val dir = File(context.filesDir, "profile").apply { mkdirs() }
                    val target = File(dir, "avatar_${System.currentTimeMillis()}.img")
                    FileOutputStream(target).use { output -> input.copyTo(output) }
                    target.absolutePath
                } } catch (_: Exception) { null }
            }
            if (saved != null) { photoPath = saved; prefs.edit().putString("profile_photo_path", saved).apply() }
        }
    }
    val history = videos.filter { prefs.getLong("last_watched_${it.uri.hashCode()}", 0L) > 0L }
        .sortedByDescending { prefs.getLong("last_watched_${it.uri.hashCode()}", 0L) }
    val visible = when (section) {
        "Histórico" -> history; "Curtidos" -> videos.filter { it.uri in liked }; "Assistir mais tarde" -> videos.filter { it.uri in later }
        "Vídeos" -> videos.filter { !it.isShort }; "Shorts" -> videos.filter { it.isShort }; else -> videos
    }
    val selectedPlaylist = playlists.firstOrNull { it.id == selectedPlaylistId }
    val selectedPlaylistVideos = selectedPlaylist?.videoUris?.mapNotNull { uri -> videos.firstOrNull { it.uri == uri } }.orEmpty()
    fun savePlaylistList(next: List<LocalPlaylist>) { playlists = next; savePlaylists(prefs, next) }
    fun openPlaylistEditor(existing: LocalPlaylist? = null) {
        editingPlaylist = existing
        playlistName = existing?.name ?: ""
        playlistDescription = existing?.description ?: ""
        playlistSelection = existing?.videoUris?.toSet() ?: emptySet()
        playlistCoverUri = existing?.coverUri
        playlistCoverImagePath = existing?.coverImagePath
        showCreate = true
    }
    Column(Modifier.fillMaxSize().background(Bg)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Você", color = TextMain, fontSize = 25.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            TextButton(onClick = { editName = profileName; editHandle = profileHandle; editDescription = profileDescription; showEdit = true }) { Text("Editar perfil", color = Accent) }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            val avatar = remember(photoPath) { try { photoPath?.let { BitmapFactory.decodeFile(it) } } catch (_: Exception) { null } }
            Box(Modifier.size(68.dp).clip(CircleShape).background(SurfaceDark).clickable { photoPicker.launch(arrayOf("image/*")) }, contentAlignment = Alignment.Center) {
                if (avatar != null) Image(avatar.asImageBitmap(), "Foto de perfil", Modifier.fillMaxSize(), contentScale = androidx.compose.ui.layout.ContentScale.Crop)
                else Icon(Icons.Default.Person, "Escolher foto", tint = TextMain, modifier = Modifier.size(42.dp))
            }
            Column(Modifier.weight(1f).padding(start = 13.dp)) {
                Text(profileName, color = TextMain, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text(profileHandle, color = TextMuted, fontSize = 13.sp)
                if (profileDescription.isNotBlank()) Text(profileDescription, color = TextMuted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = onOpenChannel, modifier = Modifier.weight(1f)) { Text("Meu canal", maxLines = 1) }
            OutlinedButton(onClick = { section = "Playlists"; selectedPlaylistId = null }, modifier = Modifier.weight(1f)) { Text("Playlists", maxLines = 1) }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("${videos.size} itens", color = TextMuted, fontSize = 12.sp)
            Text("· ${history.size} no histórico", color = TextMuted, fontSize = 12.sp)
            Text("· ${liked.size} curtidos", color = TextMuted, fontSize = 12.sp)
        }
        Row(Modifier.fillMaxWidth().padding(vertical = 12.dp).horizontalScroll(androidx.compose.foundation.rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Biblioteca", "Histórico", "Curtidos", "Assistir mais tarde", "Vídeos", "Shorts", "Playlists").forEach { item -> FilterChip(selected = section == item, onClick = { section = item; selectedPlaylistId = null }, label = { Text(item) }) }
        }
        when {
            section == "Playlists" && selectedPlaylist != null -> {
                Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { selectedPlaylistId = null }) { Icon(Icons.Default.ArrowBack, "Voltar", tint = TextMain) }
                    Column(Modifier.weight(1f)) { Text(selectedPlaylist.name, color = TextMain, fontSize = 18.sp, fontWeight = FontWeight.Bold); Text("${selectedPlaylistVideos.size} vídeos · ${selectedPlaylist.description}", color = TextMuted, fontSize = 12.sp, maxLines = 1) }
                    TextButton(onClick = { openPlaylistEditor(selectedPlaylist) }) { Text("Editar", color = Accent) }
                    TextButton(onClick = { savePlaylistList(playlists.filterNot { it.id == selectedPlaylist.id }); selectedPlaylistId = null }) { Text("Excluir", color = Accent) }
                }
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { onPlayPlaylist(selectedPlaylist, null) }, enabled = selectedPlaylistVideos.isNotEmpty(), colors = ButtonDefaults.buttonColors(containerColor = Accent)) { Icon(Icons.Default.PlayArrow, null); Text("Reproduzir") }
                    TextButton(onClick = { prefs.edit().putBoolean("shuffle_enabled", true).apply(); onPlayPlaylist(selectedPlaylist, null) }) { Icon(Icons.Default.Shuffle, null); Text("Aleatório") }
                }
                if (selectedPlaylistVideos.isEmpty()) EmptyScreen("Playlist vazia", "Edite a playlist para adicionar vídeos.", Icons.Default.QueueMusic)
                else LazyColumn {
                    items(selectedPlaylistVideos, key = { "pl_${selectedPlaylist.id}_${it.uri}" }) { v ->
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.weight(1f)) { VideoRow(v, onClick = { if (v.isShort) onShort(v) else onPlayPlaylist(selectedPlaylist, v.uri) }) }
                            Column {
                                IconButton(onClick = { val i = selectedPlaylist.videoUris.indexOf(v.uri); if (i > 0) { val l = selectedPlaylist.videoUris.toMutableList(); val a = l[i-1]; l[i-1] = l[i]; l[i] = a; savePlaylistList(playlists.map { if (it.id == selectedPlaylist.id) it.copy(videoUris = l) else it }) } }) { Icon(Icons.Default.ArrowUpward, "Mover para cima", tint = TextMain) }
                                IconButton(onClick = { val i = selectedPlaylist.videoUris.indexOf(v.uri); if (i in 0 until selectedPlaylist.videoUris.lastIndex) { val l = selectedPlaylist.videoUris.toMutableList(); val a = l[i+1]; l[i+1] = l[i]; l[i] = a; savePlaylistList(playlists.map { if (it.id == selectedPlaylist.id) it.copy(videoUris = l) else it }) } }) { Icon(Icons.Default.ArrowDownward, "Mover para baixo", tint = TextMain) }
                            }
                        }
                    }
                }
            }
            section == "Playlists" -> {
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Suas playlists", color = TextMain, fontSize = 19.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Button(onClick = { openPlaylistEditor() }, colors = ButtonDefaults.buttonColors(containerColor = Accent)) { Icon(Icons.Default.Add, null); Text("Criar") }
                }
                if (playlists.isEmpty()) EmptyScreen("Nenhuma playlist", "Crie uma playlist para organizar seus vídeos locais.", Icons.Default.QueueMusic)
                else LazyColumn { items(playlists, key = { it.id }) { pl ->
                    Row(Modifier.fillMaxWidth().clickable { selectedPlaylistId = pl.id }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(76.dp, 58.dp).clip(RoundedCornerShape(8.dp)).background(SurfaceDark), contentAlignment = Alignment.Center) {
                            val cover = pl.coverUri?.let { videos.firstOrNull { v -> v.uri == it } }
                            when {
                                pl.coverImagePath != null && File(pl.coverImagePath).exists() -> {
                                    val coverBitmap = remember(pl.coverImagePath) { BitmapFactory.decodeFile(pl.coverImagePath) }
                                    if (coverBitmap != null) Image(coverBitmap.asImageBitmap(), "Capa da playlist", Modifier.fillMaxSize(), contentScale = androidx.compose.ui.layout.ContentScale.Crop)
                                    else if (cover != null) VideoThumbnail(cover.uri, Modifier.fillMaxSize()) else Icon(Icons.Default.QueueMusic, null, tint = Accent)
                                }
                                cover != null -> VideoThumbnail(cover.uri, Modifier.fillMaxSize())
                                else -> Icon(Icons.Default.QueueMusic, null, tint = Accent)
                            }
                        }
                        Column(Modifier.weight(1f).padding(start = 12.dp)) { Text(pl.name, color = TextMain, fontWeight = FontWeight.SemiBold); Text("${pl.videoUris.size} vídeos", color = TextMuted, fontSize = 12.sp); if (pl.description.isNotBlank()) Text(pl.description, color = TextMuted, fontSize = 12.sp, maxLines = 1) }
                        Icon(Icons.Default.ArrowBack, null, tint = TextMuted, modifier = Modifier.size(18.dp))
                    }
                } }
            }
            visible.isEmpty() -> EmptyScreen(when(section) { "Histórico" -> "Seu histórico está vazio"; "Curtidos" -> "Nenhum vídeo curtido"; "Assistir mais tarde" -> "Sua lista está vazia"; else -> "Nada por aqui ainda" }, when(section) { "Histórico" -> "Os vídeos reproduzidos aparecerão aqui."; "Curtidos" -> "Os vídeos que você curtir aparecerão aqui."; "Assistir mais tarde" -> "Salve vídeos para assistir depois."; else -> "Importe vídeos pela aba Enviar." }, Icons.Default.LibraryBooks)
            else -> LazyColumn(contentPadding = PaddingValues(bottom = 18.dp)) {
                items(visible, key = { "you_${section}_${it.uri}" }) { video ->
                    Column {
                        VideoRow(video, onClick = { if (video.isShort) onShort(video) else onVideo(video) }, onLongClick = { onRemove(video) })
                        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.End) {
                            TextButton(onClick = { val updated = liked.toMutableSet(); if (!updated.add(video.uri)) updated.remove(video.uri); prefs.edit().putStringSet("liked_video_uris", updated).apply(); refreshKey++ }) { Icon(if (video.uri in liked) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null, tint = Accent); Text(if (video.uri in liked) "Curtido" else "Curtir", color = Accent) }
                            TextButton(onClick = { val updated = later.toMutableSet(); if (!updated.add(video.uri)) updated.remove(video.uri); prefs.edit().putStringSet("watch_later_uris", updated).apply(); refreshKey++ }) { Icon(Icons.Default.WatchLater, null, tint = TextMuted); Text(if (video.uri in later) "Salvo" else "Assistir mais tarde", color = TextMuted) }
                        }
                    }
                }
            }
        }
    }
    if (showCreate) {
        AlertDialog(onDismissRequest = { showCreate = false }, title = { Text(if (editingPlaylist == null) "Criar playlist" else "Editar playlist") },
            text = { Column(Modifier.heightIn(max = 430.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = playlistName, onValueChange = { playlistName = it }, label = { Text("Nome") }, singleLine = true)
                OutlinedTextField(value = playlistDescription, onValueChange = { playlistDescription = it }, label = { Text("Descrição") }, minLines = 2)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Capa da playlist", color = TextMain, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    TextButton(onClick = { playlistCoverPicker.launch(arrayOf("image/*")) }) { Text("Escolher imagem", color = Accent) }
                }
                if (playlistCoverImagePath != null) Text("Capa personalizada selecionada", color = TextMuted, fontSize = 12.sp)
                Text("Adicionar vídeos", color = TextMain, fontWeight = FontWeight.Bold)
                LazyColumn(Modifier.heightIn(max = 230.dp)) { items(videos.filter { !it.isShort }, key = { "select_${it.uri}" }) { v ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = v.uri in playlistSelection, onCheckedChange = { checked -> playlistSelection = if (checked) playlistSelection + v.uri else playlistSelection - v.uri; if (!checked && playlistCoverUri == v.uri) playlistCoverUri = null })
                        Text(v.name, color = TextMain, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                        if (v.uri in playlistSelection) TextButton(onClick = { playlistCoverUri = v.uri }) { Text(if (playlistCoverUri == v.uri) "Capa ✓" else "Usar capa", color = Accent) }
                    }
                } }
                Text("Você pode usar uma imagem da galeria ou escolher um vídeo abaixo como capa.", color = TextMuted, fontSize = 11.sp)
            } },
            confirmButton = { TextButton(onClick = {
                val old = editingPlaylist
                val orderedUris = (old?.videoUris.orEmpty().filter { it in playlistSelection } + videos.map { it.uri }.filter { it in playlistSelection && it !in old?.videoUris.orEmpty() }).distinct()
                val next = LocalPlaylist(old?.id ?: UUID.randomUUID().toString(), playlistName.trim().ifBlank { "Minha playlist" }, playlistDescription.trim(), orderedUris, playlistCoverUri ?: orderedUris.firstOrNull(), playlistCoverImagePath)
                savePlaylistList(if (old == null) playlists + next else playlists.map { if (it.id == old.id) next else it })
                showCreate = false
            }) { Text("Salvar", color = Accent) } }, dismissButton = { TextButton(onClick = { showCreate = false }) { Text("Cancelar") } })
    }
    if (showEdit) AlertDialog(onDismissRequest = { showEdit = false }, title = { Text("Editar perfil") }, text = { Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        OutlinedTextField(value = editName, onValueChange = { editName = it }, label = { Text("Nome") }, singleLine = true)
        OutlinedTextField(value = editHandle, onValueChange = { editHandle = it }, label = { Text("Identificador") }, singleLine = true)
        OutlinedTextField(value = editDescription, onValueChange = { editDescription = it }, label = { Text("Descrição") }, minLines = 2)
        Text("Toque na foto do perfil para escolher uma imagem da galeria.", color = TextMuted, fontSize = 12.sp)
    } }, confirmButton = { TextButton(onClick = {
        profileName = editName.trim().ifBlank { "Meu perfil" }; profileHandle = editHandle.trim().let { if (it.isBlank()) "@meuperfil" else if (it.startsWith("@")) it else "@$it" }; profileDescription = editDescription.trim()
        prefs.edit().putString("profile_name", profileName).putString("profile_handle", profileHandle).putString("profile_description", profileDescription).apply(); showEdit = false
    }) { Text("Salvar", color = Accent) } }, dismissButton = { TextButton(onClick = { showEdit = false }) { Text("Cancelar") } })
}

private fun loadPlaylists(prefs: android.content.SharedPreferences): List<LocalPlaylist> = try {
    val arr = JSONArray(prefs.getString("playlists_json", "[]") ?: "[]")
    (0 until arr.length()).map { i -> val o = arr.getJSONObject(i); val uris = o.optJSONArray("uris") ?: JSONArray(); LocalPlaylist(o.optString("id"), o.optString("name"), o.optString("description"), (0 until uris.length()).map { uris.getString(it) }, o.optString("cover").takeIf { it.isNotBlank() }, o.optString("coverImagePath").takeIf { it.isNotBlank() }) }
} catch (_: Exception) { emptyList() }
private fun savePlaylists(prefs: android.content.SharedPreferences, playlists: List<LocalPlaylist>) {
    val arr = JSONArray(); playlists.forEach { p -> val uris = JSONArray(); p.videoUris.forEach { uris.put(it) }; arr.put(JSONObject().put("id", p.id).put("name", p.name).put("description", p.description).put("uris", uris).put("cover", p.coverUri ?: "").put("coverImagePath", p.coverImagePath ?: "")) }; prefs.edit().putString("playlists_json", arr.toString()).apply()
}

@Composable
private fun EmptyScreen(title: String, message: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Icon(icon, null, tint = Accent, modifier = Modifier.size(52.dp))
        Spacer(Modifier.height(12.dp))
        Text(title, color = TextMain, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text(message, color = TextMuted, fontSize = 14.sp)
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun VideoPlayerScreen(
    video: LocalVideo, allVideos: List<LocalVideo>, queueVideos: List<LocalVideo>, previousVideoUri: String?,
    prefs: android.content.SharedPreferences, onBack: () -> Unit, onNextVideo: (String) -> Unit,
    onQueueChange: (List<String>) -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val configuration = LocalConfiguration.current
    val landscape = configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
    var manualFullscreen by rememberSaveable(video.uri) { mutableStateOf(false) }
    val isExpanded = landscape || manualFullscreen
    LaunchedEffect(landscape) { if (landscape) manualFullscreen = false }
    var showControls by remember(video.uri) { mutableStateOf(false) }
    var showSettings by remember(video.uri) { mutableStateOf(false) }
    var shuffleEnabled by remember { mutableStateOf(prefs.getBoolean("shuffle_enabled", false)) }
    var repeatVideo by remember { mutableStateOf(prefs.getBoolean("repeat_video", false)) }
    var repeatPlaylist by remember { mutableStateOf(prefs.getBoolean("repeat_playlist", false)) }
    var isPlaying by remember(video.uri) { mutableStateOf(true) }
    var isLiked by remember(video.uri) { mutableStateOf(prefs.getStringSet("liked_video_uris", emptySet()).orEmpty().contains(video.uri)) }
    var isSaved by remember(video.uri) { mutableStateOf(prefs.getStringSet("watch_later_uris", emptySet()).orEmpty().contains(video.uri)) }
    var playbackSpeed by remember { mutableFloatStateOf(prefs.getFloat("playback_speed", 1f)) }
    var resumeAfterLifecyclePause by remember(video.uri) { mutableStateOf(false) }
    var controlsNonce by remember { mutableIntStateOf(0) }
    var playbackPosition by remember(video.uri) { mutableLongStateOf(0L) }
    var playbackDuration by remember(video.uri) { mutableLongStateOf(0L) }
    var isScrubbing by remember(video.uri) { mutableStateOf(false) }
    var scrubPosition by remember(video.uri) { mutableFloatStateOf(0f) }
    val scope = rememberCoroutineScope()
    val playbackList = if (queueVideos.isNotEmpty()) queueVideos else allVideos
    val currentIndex = playbackList.indexOfFirst { it.uri == video.uri }
    val nextVideo = remember(video.uri, playbackList, shuffleEnabled, repeatPlaylist) {
        val eligible = playbackList.filter { it.uri != video.uri }
        if (eligible.isEmpty()) { if (repeatPlaylist) playbackList.firstOrNull() else null } else if (shuffleEnabled) eligible.random() else {
            val index = playbackList.indexOfFirst { it.uri == video.uri }
            playbackList.getOrNull(index + 1) ?: if (repeatPlaylist) playbackList.firstOrNull() else null
        }
    }
    val previousVideo = previousVideoUri?.let { uri -> allVideos.firstOrNull { it.uri == uri } } ?: playbackList.getOrNull(currentIndex - 1)
    val likedForRecommendations = prefs.getStringSet("liked_video_uris", emptySet()).orEmpty()
    val laterForRecommendations = prefs.getStringSet("watch_later_uris", emptySet()).orEmpty()
    val preferredCategories = prefs.getStringSet("preferred_video_categories", emptySet()).orEmpty()
    val recommended = remember(video.uri, allVideos, likedForRecommendations, laterForRecommendations, preferredCategories) {
        val tokens = video.name.lowercase().split(Regex("\\W+")).filter { it.length > 3 }.toSet()
        val currentCategory = inferVideoCategory(video.name)
        allVideos.filter { it.uri != video.uri }.sortedByDescending { candidate ->
            val candidateTokens = candidate.name.lowercase().split(Regex("\\W+")).filter { it.length > 3 }.toSet()
            val similar = candidateTokens.intersect(tokens).size
            val category = inferVideoCategory(candidate.name)
            val sameCategory = if (category == currentCategory) 5 else 0
            val preferred = if (category in preferredCategories) 8 else 0
            val liked = if (candidate.uri in likedForRecommendations) 3 else 0
            val saved = if (candidate.uri in laterForRecommendations) 2 else 0
            val watched = prefs.getLong("last_watched_${candidate.uri.hashCode()}", 0L)
            val recency = if (watched > 0L) 1 else 0
            similar * 100 + preferred * 20 + sameCategory * 10 + liked * 50 + saved * 15 + recency
        }.take(8)
    }
    val player = remember(video.uri) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(video.uri))
            val savedPosition = prefs.getLong(progressKey(video.uri), 0L)
            if (savedPosition > 3_000L) seekTo(savedPosition)
            setPlaybackSpeed(prefs.getFloat("playback_speed", 1f))
            prepare(); playWhenReady = true
        }
    }
    fun revealControls() { showControls = true; controlsNonce++ }
    fun toggleLike() {
        val set = prefs.getStringSet("liked_video_uris", emptySet()).orEmpty().toMutableSet()
        if (!set.add(video.uri)) set.remove(video.uri)
        prefs.edit().putStringSet("liked_video_uris", set).apply(); isLiked = set.contains(video.uri)
    }
    fun toggleSaved() {
        val set = prefs.getStringSet("watch_later_uris", emptySet()).orEmpty().toMutableSet()
        if (!set.add(video.uri)) set.remove(video.uri)
        prefs.edit().putStringSet("watch_later_uris", set).apply(); isSaved = set.contains(video.uri)
    }
    LaunchedEffect(video.uri) {
        while (true) {
            if (!isScrubbing) playbackPosition = player.currentPosition.coerceAtLeast(0L)
            playbackDuration = player.duration.coerceAtLeast(0L)
            delay(400)
        }
    }
    BackHandler {
        if (showSettings) showSettings = false else if (manualFullscreen && !landscape) manualFullscreen = false else onBack()
    }
    DisposableEffect(isExpanded) {
        val window = (context as? Activity)?.window
        val controller = window?.let { WindowCompat.getInsetsController(it, it.decorView) }
        if (isExpanded) { controller?.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE; controller?.hide(WindowInsetsCompat.Type.systemBars()) }
        else controller?.show(WindowInsetsCompat.Type.systemBars())
        onDispose { controller?.show(WindowInsetsCompat.Type.systemBars()) }
    }
    DisposableEffect(lifecycleOwner, player, video.uri) {
        recordWatch(prefs, video.uri)
        val observer = LifecycleEventObserver { _, event -> when (event) {
            Lifecycle.Event.ON_PAUSE -> { resumeAfterLifecyclePause = player.playWhenReady; savePlaybackProgress(prefs, video.uri, player.currentPosition, player.duration); player.pause() }
            Lifecycle.Event.ON_RESUME -> { if (resumeAfterLifecyclePause) player.play(); resumeAfterLifecyclePause = false }
            else -> Unit
        } }
        val listener = object : androidx.media3.common.Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) { isPlaying = playing }
            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == androidx.media3.common.Player.STATE_ENDED) {
                    prefs.edit().remove(progressKey(video.uri)).apply()
                    when {
                        repeatVideo -> { player.seekTo(0); player.play() }
                        (prefs.getBoolean("autoplay", true) || repeatPlaylist) && nextVideo != null -> {
                            if (nextVideo.uri == video.uri) { player.seekTo(0); player.play() }
                            else onNextVideo(nextVideo.uri)
                        }
                    }
                }
            }
        }
        player.addListener(listener); lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { savePlaybackProgress(prefs, video.uri, player.currentPosition, player.duration); player.removeListener(listener); lifecycleOwner.lifecycle.removeObserver(observer); player.release() }
    }
    LaunchedEffect(video.uri, controlsNonce, isExpanded) {
        if (showControls) { delay(4000); showControls = false }
    }
    Column(Modifier.fillMaxSize().background(if (isExpanded) Color.Black else Bg).then(if (isExpanded) Modifier else Modifier.systemBarsPadding())) {
        if (!isExpanded) Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Voltar", tint = TextMain) }
            Text(video.name, color = TextMain, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Box(
            Modifier.fillMaxWidth()
                .then(if (isExpanded) Modifier.weight(1f) else Modifier.aspectRatio(16f / 9f))
                .background(Color.Black)
        ) {
            AndroidView(
                factory = { ctx -> PlayerView(ctx).apply {
                    this.player = player
                    useController = false
                    setShutterBackgroundColor(android.graphics.Color.BLACK)
                    resizeMode = androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIT
                    setOnTouchListener { _, _ -> false }
                } },
                update = { it.player = player; it.resizeMode = androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIT },
                modifier = Modifier.fillMaxSize()
            )
            Box(Modifier.fillMaxSize().pointerInput(video.uri) { detectTapGestures(onTap = { revealControls() }) })
            if (showControls) {
                Box(Modifier.fillMaxSize()) {
                    Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.30f)))
                    Row(
                        Modifier.fillMaxWidth().align(Alignment.TopCenter)
                            .background(androidx.compose.ui.graphics.Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.70f), Color.Transparent)))
                            .padding(horizontal = 6.dp, vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (isExpanded) {
                            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Voltar", tint = Color.White) }
                            Text(video.name, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                        } else Spacer(Modifier.weight(1f))
                        IconButton(onClick = { showSettings = true; revealControls() }) { Icon(Icons.Default.Settings, "Configurações e velocidade", tint = Color.White) }
                        IconButton(onClick = { if (landscape) manualFullscreen = false else manualFullscreen = !manualFullscreen; revealControls() }) {
                            Icon(if (isExpanded) Icons.Default.FullscreenExit else Icons.Default.Fullscreen, "Tela cheia", tint = Color.White)
                        }
                    }
                    Row(Modifier.align(Alignment.Center), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(20.dp)) {
                        IconButton(onClick = {
                            if (previousVideo != null) onNextVideo(previousVideo.uri) else { player.seekTo(0); player.play() }
                            revealControls()
                        }, modifier = Modifier.size(48.dp).clip(CircleShape).background(Color.Black.copy(alpha = 0.40f))) {
                            Icon(Icons.Default.SkipPrevious, if (previousVideo != null) "Vídeo anterior" else "Recomeçar vídeo", tint = Color.White, modifier = Modifier.size(28.dp))
                        }
                        IconButton(onClick = { if (player.isPlaying) player.pause() else player.play(); revealControls() },
                            modifier = Modifier.size(62.dp).clip(CircleShape).background(Color.Black.copy(alpha = 0.45f))) {
                            Icon(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, if (isPlaying) "Pausar" else "Continuar", tint = Color.White, modifier = Modifier.size(38.dp))
                        }
                        IconButton(onClick = { nextVideo?.let { onNextVideo(it.uri) }; revealControls() }, enabled = nextVideo != null,
                            modifier = Modifier.size(48.dp).clip(CircleShape).background(Color.Black.copy(alpha = 0.40f))) {
                            Icon(Icons.Default.SkipNext, "Próximo vídeo", tint = if (nextVideo != null) Color.White else Color.White.copy(alpha = 0.4f), modifier = Modifier.size(28.dp))
                        }
                    }
                    Column(
                        Modifier.fillMaxWidth().align(Alignment.BottomCenter)
                            .background(androidx.compose.ui.graphics.Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.75f))))
                            .padding(horizontal = 14.dp, vertical = 2.dp)
                    ) {
                        Slider(
                            value = if (isScrubbing) scrubPosition else if (playbackDuration > 0L) playbackPosition.toFloat().coerceAtMost(playbackDuration.toFloat()) else 0f,
                            onValueChange = { value -> isScrubbing = true; scrubPosition = value },
                            onValueChangeFinished = { player.seekTo(scrubPosition.toLong().coerceAtLeast(0L)); playbackPosition = scrubPosition.toLong(); isScrubbing = false; revealControls() },
                            valueRange = 0f..(playbackDuration.coerceAtLeast(1L).toFloat()),
                            modifier = Modifier.fillMaxWidth().height(22.dp),
                            colors = SliderDefaults.colors(thumbColor = Accent, activeTrackColor = Accent, inactiveTrackColor = Color.White.copy(alpha = 0.35f))
                        )
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text("${formatPlayerTime(if (isScrubbing) scrubPosition.toLong() else playbackPosition)} / ${formatPlayerTime(playbackDuration)}", color = Color.White, fontSize = 12.sp, modifier = Modifier.weight(1f))
                            IconButton(onClick = { toggleLike(); revealControls() }, modifier = Modifier.size(38.dp)) {
                                Icon(if (isLiked) Icons.Default.Favorite else Icons.Default.FavoriteBorder, "Curtir", tint = if (isLiked) Accent else Color.White, modifier = Modifier.size(22.dp))
                            }
                            IconButton(onClick = { toggleSaved(); revealControls() }, modifier = Modifier.size(38.dp)) {
                                Icon(if (isSaved) Icons.Default.Bookmark else Icons.Default.BookmarkBorder, "Salvar", tint = if (isSaved) Accent else Color.White, modifier = Modifier.size(22.dp))
                            }
                            IconButton(onClick = { showSettings = true; revealControls() }, modifier = Modifier.size(38.dp)) {
                                Icon(Icons.Default.MoreHoriz, "Mais opções", tint = Color.White, modifier = Modifier.size(22.dp))
                            }
                        }
                    }
                }
            }
        }
        if (!isExpanded) LazyColumn(Modifier.weight(1f).fillMaxWidth(), contentPadding = PaddingValues(bottom = 24.dp)) {
            item { Text(video.name, color = TextMain, fontSize = 19.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp)) }
            item { Text("Vídeo da sua biblioteca · Reprodução local", color = TextMuted, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 16.dp)) }
            item { ThumbnailEditor(video) }
            item { Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), horizontalArrangement = Arrangement.End) {
                TextButton(onClick = { toggleLike() }) { Icon(if (isLiked) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null, tint = Accent); Spacer(Modifier.width(6.dp)); Text(if (isLiked) "Curtido" else "Curtir", color = Accent) }
                TextButton(onClick = { toggleSaved() }) { Icon(if (isSaved) Icons.Default.Bookmark else Icons.Default.BookmarkBorder, null, tint = if (isSaved) Accent else TextMuted); Spacer(Modifier.width(6.dp)); Text(if (isSaved) "Salvo" else "Salvar", color = if (isSaved) Accent else TextMuted) }
            } }
            if (queueVideos.isNotEmpty()) {
                item {
                    Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp, top = 14.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("Fila de reprodução", color = TextMain, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        TextButton(onClick = { onQueueChange(emptyList()) }) { Text("Limpar fila", color = Accent) }
                    }
                }
                items(queueVideos.filter { it.uri != video.uri }, key = { "queue_${it.uri}" }) { queued ->
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.weight(1f)) { VideoRow(queued, onClick = { onNextVideo(queued.uri) }) }
                        Column {
                            IconButton(onClick = { onQueueChange(queueVideos.filterNot { it.uri == queued.uri }.map { it.uri }) }) {
                                Icon(Icons.Default.Close, "Remover da fila", tint = TextMuted)
                            }
                            IconButton(onClick = {
                                val mutable = queueVideos.map { it.uri }.toMutableList()
                                val index = mutable.indexOf(queued.uri)
                                if (index > 0) { val previous = mutable[index - 1]; mutable[index - 1] = mutable[index]; mutable[index] = previous; onQueueChange(mutable) }
                            }) { Icon(Icons.Default.ArrowUpward, "Mover para cima na fila", tint = TextMain) }
                            IconButton(onClick = {
                                val mutable = queueVideos.map { it.uri }.toMutableList()
                                val index = mutable.indexOf(queued.uri)
                                if (index >= 0 && index < mutable.lastIndex) { val next = mutable[index + 1]; mutable[index + 1] = mutable[index]; mutable[index] = next; onQueueChange(mutable) }
                            }) { Icon(Icons.Default.ArrowDownward, "Mover para baixo na fila", tint = TextMain) }
                        }
                    }
                }
            }
            item { Text("Vídeos recomendados", color = TextMain, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 16.dp, top = 14.dp, bottom = 8.dp)) }
            if (recommended.isEmpty()) item { Text("Adicione mais vídeos para receber recomendações locais.", color = TextMuted, fontSize = 13.sp, modifier = Modifier.padding(16.dp)) }
            items(recommended, key = { "recommended_${it.uri}" }) { rec ->
                Column {
                    VideoRow(rec, onClick = { onNextVideo(rec.uri) })
                    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.End) {
                        TextButton(onClick = {
                            val base = (queueVideos.ifEmpty { allVideos }).map { it.uri }.toMutableList()
                            if (rec.uri !in base) base.add(rec.uri)
                            onQueueChange(base)
                        }) { Icon(Icons.Default.QueueMusic, null, tint = Accent); Text("Adicionar à fila", color = Accent) }
                    }
                }
            }
        }
    }
    if (showSettings) AlertDialog(onDismissRequest = { showSettings = false }, title = { Text("Configurações de reprodução") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Velocidade de reprodução", fontWeight = FontWeight.SemiBold)
            Row(Modifier.horizontalScroll(androidx.compose.foundation.rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf(0.5f to "0,5x", 0.75f to "0,75x", 1f to "Normal", 1.25f to "1,25x", 1.5f to "1,5x", 2f to "2x").forEach { (speed, label) ->
                    FilterChip(selected = playbackSpeed == speed, onClick = { playbackSpeed = speed; player.setPlaybackSpeed(speed); prefs.edit().putFloat("playback_speed", speed).apply() }, label = { Text(label, maxLines = 1, softWrap = false) })
                }
            }
            SettingSwitch("Reprodução aleatória", "Escolher o próximo vídeo aleatoriamente", shuffleEnabled) { shuffleEnabled = it; prefs.edit().putBoolean("shuffle_enabled", it).apply() }
            SettingSwitch("Repetir vídeo atual", "Reiniciar este vídeo ao terminar", repeatVideo) { repeatVideo = it; prefs.edit().putBoolean("repeat_video", it).apply() }
            SettingSwitch("Repetir playlist", "Recomeçar a fila ao terminar", repeatPlaylist) { repeatPlaylist = it; prefs.edit().putBoolean("repeat_playlist", it).apply() }
        }
    }, confirmButton = { TextButton(onClick = { showSettings = false }) { Text("Concluir") } })
}

private fun formatPlayerTime(milliseconds: Long): String {
    val totalSeconds = (milliseconds.coerceAtLeast(0L) / 1000L)
    val hours = totalSeconds / 3600L
    val minutes = (totalSeconds % 3600L) / 60L
    val seconds = totalSeconds % 60L
    return if (hours > 0) String.format(java.util.Locale.ROOT, "%d:%02d:%02d", hours, minutes, seconds)
    else String.format(java.util.Locale.ROOT, "%d:%02d", minutes, seconds)
}

private fun inferVideoCategory(title: String): String {
    val value = title.lowercase()
    return when {
        listOf("game", "gaming", "minecraft", "roblox", "free fire", "fortnite", "gta", "jogo").any { it in value } -> "Jogos"
        listOf("music", "música", "musica", "song", "audio", "cover", "remix").any { it in value } -> "Música"
        listOf("futebol", "football", "soccer", "basquete", "nba", "esporte", "corrida").any { it in value } -> "Esportes"
        listOf("tech", "tecnologia", "android", "iphone", "celular", "pc", "computador").any { it in value } -> "Tecnologia"
        listOf("aula", "tutorial", "como fazer", "explicação", "explicacao", "estudo", "matemática", "matematica").any { it in value } -> "Educação"
        listOf("engraçado", "engracado", "comédia", "comedia", "meme", "piada", "humor").any { it in value } -> "Comédia"
        listOf("filme", "série", "serie", "trailer", "entretenimento", "review", "react").any { it in value } -> "Entretenimento"
        else -> "Outros"
    }
}

private fun copyVideoToPrivateStorage(context: Context, source: Uri, displayName: String): Uri {
    val directory = File(context.filesDir, "videos").apply { if (!exists() && !mkdirs()) error("Não foi possível criar a pasta de vídeos") }
    val extension = queryFileExtension(context, source).ifBlank { "mp4" }
    val safeExtension = extension.filter { it.isLetterOrDigit() }.take(8).ifBlank { "mp4" }
    val destination = File(directory, "${UUID.randomUUID()}.$safeExtension")
    try {
        val input = context.contentResolver.openInputStream(source) ?: error("Não foi possível abrir o vídeo selecionado")
        input.use { stream -> FileOutputStream(destination).use { output -> stream.copyTo(output, 1024 * 1024); output.fd.sync() } }
        if (!destination.exists() || destination.length() == 0L) error("O arquivo importado está vazio")
        return Uri.fromFile(destination)
    } catch (e: Exception) {
        destination.delete()
        throw e
    }
}

private fun queryFileExtension(context: Context, uri: Uri): String {
    val name = try {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
    } catch (_: Exception) { null }
    return name?.substringAfterLast('.', "")?.lowercase().orEmpty()
}

private fun deletePrivateVideoIfOwned(context: Context, uriString: String) {
    try {
        val uri = Uri.parse(uriString)
        if (uri.scheme != "file") return
        val file = File(uri.path ?: return).canonicalFile
        val ownedDirectory = File(context.filesDir, "videos").canonicalFile
        if (file.parentFile == ownedDirectory) file.delete()
    } catch (_: Exception) { }
}

private fun loadVideos(prefs: android.content.SharedPreferences): List<LocalVideo> {
    val json = prefs.getString("videos_json", null)
    if (json != null) {
        return try {
            val arr = JSONArray(json)
            (0 until arr.length()).map { idx ->
                val o = arr.getJSONObject(idx)
                LocalVideo(o.getString("uri"), o.getString("name"), o.optBoolean("short", false), o.optString("thumbnailPath").takeIf { it.isNotBlank() })
            }
        } catch (_: Exception) { emptyList() }
    }
    // Migração do formato antigo (1.4 e anteriores)
    return prefs.getStringSet("videos", emptySet()).orEmpty().mapNotNull { line ->
        val parts = line.split("\t")
        if (parts.size >= 3) LocalVideo(parts[0], parts[1], parts[2] == "1") else null
    }
}

private fun saveVideos(prefs: android.content.SharedPreferences, videos: List<LocalVideo>) {
    val arr = JSONArray()
    videos.forEach { arr.put(JSONObject().put("uri", it.uri).put("name", it.name).put("short", it.isShort).put("thumbnailPath", it.thumbnailPath ?: "")) }
    prefs.edit().putString("videos_json", arr.toString()).remove("videos").apply()
}

private fun queryDisplayName(context: Context, uri: Uri): String {
    val fromProvider = try {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
    } catch (_: Exception) { null }
    val raw = fromProvider ?: uri.lastPathSegment?.substringAfterLast('/') ?: "Vídeo importado"
    return raw.substringBeforeLast('.', raw).ifBlank { "Vídeo importado" }
}

private fun progressKey(uri: String): String = "playback_progress_${uri.hashCode()}"

private fun savePlaybackProgress(
    prefs: android.content.SharedPreferences,
    uri: String,
    position: Long,
    duration: Long
) {
    if (position > 3_000L && (duration <= 0L || position < duration - 3_000L)) {
        prefs.edit().putLong(progressKey(uri), position).apply()
    } else if (duration > 0L && position >= duration - 3_000L) {
        prefs.edit().remove(progressKey(uri)).apply()
    }
}

private fun recordWatch(prefs: android.content.SharedPreferences, uri: String) {
    prefs.edit().putLong("last_watched_${uri.hashCode()}", System.currentTimeMillis()).apply()
}
