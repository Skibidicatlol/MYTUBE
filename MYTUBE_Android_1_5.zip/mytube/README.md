# MYTUBE 1.5 — Android project

Aplicativo pessoal de vídeos com prioridade offline, interface escura e sem anúncios. Tudo roda localmente (Media3 / ExoPlayer + Jetpack Compose).

## O que já funciona
- Início com categorias (por palavras-chave no nome), "Continuar assistindo" e ordenação pelo histórico local.
- Importação pelo seletor nativo do Android, com o nome real do arquivo (sem extensão).
- Biblioteca persistente (ordem preservada) e remoção com toque longo.
- Miniaturas automáticas via MediaMetadataRetriever.
- Player com controles Media3, modo expandido (esconde as barras do sistema), retomada de posição e histórico.
- Shorts: lista e feed vertical em tela cheia com reprodução automática e repetição.
- Busca por nome (Início e Shorts).
- Botão Voltar correto no player; rotação sem perder o vídeo; barras do sistema respeitadas no Android 15.

## Ainda não implementado
- Inscrições (tela placeholder), Downloads gerenciados, playlists, legendas.
- Nuvem / autenticação.

## Como compilar
Abra a pasta `mytube` no Android Studio (JDK 17, Android SDK 35) e use **Build > Build APK(s)**. Ou use o workflow `.github/workflows/build-apk.yml` (Actions > Build MYTUBE APK > Run workflow) e baixe o artefato `MYTUBE-debug-apk`.

Nota: a 1.5 ainda não foi compilada nem testada em dispositivo.
