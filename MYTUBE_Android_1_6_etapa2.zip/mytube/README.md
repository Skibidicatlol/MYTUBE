# MYTUBE 1.6 — Android project

Aplicativo pessoal de vídeos com prioridade offline, interface escura e sem anúncios. Tudo roda localmente (Media3 / ExoPlayer + Jetpack Compose).

## Base da versão 1.6
- Novas importações são copiadas para `filesDir/videos` no armazenamento privado do MYTUBE, usando cópia em segundo plano.
- A cópia é validada e removida se a importação falhar.
- Remover um vídeo da biblioteca também apaga a cópia privada correspondente, sem apagar arquivos externos.
- Vídeos já cadastrados na 1.5 continuam preservados como referências antigas; a migração desses itens será feita em etapa própria para não arriscar perder acesso.

## O que já funciona (herdado da 1.5)
- Início com categorias (por palavras-chave no nome), "Continuar assistindo" e ordenação pelo histórico local.
- Importação pelo seletor nativo do Android, com o nome real do arquivo (sem extensão).
- Biblioteca persistente (ordem preservada) e remoção com toque longo.
- Miniaturas automáticas via MediaMetadataRetriever.
- Player com controles Media3, modo expandido (esconde as barras do sistema), retomada de posição e histórico.
- Shorts: lista e feed vertical em tela cheia com reprodução automática e repetição.
- Busca por nome (Início e Shorts).
- Botão Voltar correto no player; rotação sem perder o vídeo; barras do sistema respeitadas no Android 15.

## Ainda não implementado
- Inscrições (tela placeholder), Downloads gerenciados, playlists, legendas.
- Nuvem / autenticação.

## Como compilar
Abra a pasta `mytube` no Android Studio (JDK 17, Android SDK 35) e use **Build > Build APK(s)**. Ou use o workflow `.github/workflows/build-apk.yml` (Actions > Build MYTUBE APK > Run workflow) e baixe o artefato `MYTUBE-debug-apk`.

Nota: esta etapa 1.6 ainda precisa ser compilada e testada em dispositivo.


## MYTUBE 1.6 — Etapa 2
- Player reformulado com controles Compose sobre o vídeo.
- Oculte/mostre os controles tocando na área do vídeo; eles desaparecem automaticamente após alguns segundos.
- Tela cheia agora fica na mesma barra de controles, imediatamente à direita do botão de configurações.
- Botão Próximo vídeo troca de fato para outro vídeo da biblioteca; fica desativado quando não há outro vídeo disponível.
- Configurações de reprodução incluem alternância de ordem aleatória, respeitada pelo botão Próximo.
- Player usa `RESIZE_MODE_FIT` para manter o vídeo centralizado sem cortar a imagem em diferentes proporções.
- Esta etapa ainda precisa ser compilada e testada no Android/GitHub Actions.
