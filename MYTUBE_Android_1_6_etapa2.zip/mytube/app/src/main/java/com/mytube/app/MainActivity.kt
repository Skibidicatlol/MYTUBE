package com.mytube.app

import android.app.Activity
import android.content.Context
import android.provider.OpenableColumns
import androidx.compose.foundation.combinedClickable
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import org.json.JSONArray
import org.json.JSONObject
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.FullscreenExit
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LibraryBooks
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Subscriptions
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.produceState
import android.graphics.Bitmap
import java.io.File
import java.io.FileOutputStream
import java.util.UUID
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import android.media.MediaMetadataRetriever
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private val Bg = Color(0xFF0B0B0B)
private val SurfaceDark = Color(0xFF191919)
private val TextMain = Color(0xFFF5F5F5)
private val TextMuted = Color(0xFFAAAAAA)
private val Accent = Color(0xFFFF0033)

private data class LocalVideo(val uri: String, val name: String, val isShort: Boolean)
private enum class Tab(val label: String) { HOME("Início"), SHORTS("Shorts"), UPLOAD("Enviar"), SUBSCRIPTIONS("Inscrições"), YOU("Você") }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MyTubeApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MyTubeApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("mytube_library", Context.MODE_PRIVATE) }
    var videos by remember {
        mutableStateOf(loadVideos(prefs).map { v ->
            if (v.name.all { it.isDigit() }) v.copy(name = queryDisplayName(context, Uri.parse(v.uri))) else v
        })
    }
    var selectedTab by remember { mutableStateOf(Tab.HOME) }
    var selectedVideoUri by rememberSaveable { mutableStateOf<String?>(null) }
    var selectedShortUri by rememberSaveable { mutableStateOf<String?>(null) }
    var searchText by rememberSaveable { mutableStateOf("") }
    var searchActive by rememberSaveable { mutableStateOf(false) }
    var videoToRemove by remember { mutableStateOf<LocalVideo?>(null) }
    val selectedVideo = videos.firstOrNull { it.uri == selectedVideoUri }
    var importAsShort by remember { mutableStateOf(false) }
    var isImporting by remember { mutableStateOf(false) }
    var importError by remember { mutableStateOf<String?>(null) }
    val importScope = rememberCoroutineScope()

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null && !isImporting) {
            val shortChoice = importAsShort
            val displayName = queryDisplayName(context, uri)
            importError = null
            isImporting = true
            importScope.launch {
                try {
                    val copiedUri = withContext(Dispatchers.IO) { copyVideoToPrivateStorage(context, uri, displayName) }
                    val item = LocalVideo(copiedUri.toString(), displayName, shortChoice)
                    videos = (videos.filterNot { it.name == item.name && it.isShort == item.isShort } + item)
                    saveVideos(prefs, videos)
                    selectedTab = if (shortChoice) Tab.SHORTS else Tab.HOME
                } catch (e: Exception) {
                    importError = "Não foi possível importar esse vídeo. Verifique se o arquivo está acessível e tente novamente."
                } finally {
                    isImporting = false
                }
            }
        }
    }

    videoToRemove?.let { target ->
        AlertDialog(
            onDismissRequest = { videoToRemove = null },
            title = { Text("Remover da biblioteca?") },
            text = { Text("“${target.name}” sai do MYTUBE. O arquivo original no celular não é apagado.") },
            confirmButton = {
                TextButton(onClick = {
                    deletePrivateVideoIfOwned(context, target.uri)
                    try { context.contentResolver.releasePersistableUriPermission(Uri.parse(target.uri), android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
                    prefs.edit().remove(progressKey(target.uri)).remove("last_watched_${target.uri.hashCode()}").apply()
                    videos = videos.filterNot { it.uri == target.uri }
                    saveVideos(prefs, videos)
                    videoToRemove = null
                }) { Text("Remover", color = Accent) }
            },
            dismissButton = { TextButton(onClick = { videoToRemove = null }) { Text("Cancelar") } }
        )
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = SurfaceDark, primary = Accent,
        onBackground = TextMain, onSurface = TextMain
    )) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            if (selectedShortUri != null) {
                ShortsPlayerScreen(
                    shorts = videos.filter { it.isShort },
                    startUri = selectedShortUri!!,
                    onBack = { selectedShortUri = null }
                )
            } else if (selectedVideo != null) {
                VideoPlayerScreen(
                    video = selectedVideo,
                    allVideos = videos.filter { !it.isShort },
                    prefs = prefs,
                    onBack = { selectedVideoUri = null },
                    onNextVideo = { nextUri -> selectedVideoUri = nextUri }
                )
            } else {
                Scaffold(
                    containerColor = Bg,
                    topBar = {
                        if (selectedTab != Tab.UPLOAD && selectedTab != Tab.YOU) {
                            TopAppBar(
                                title = {
                                    if (searchActive) {
                                        val focus = remember { FocusRequester() }
                                        LaunchedEffect(Unit) { try { focus.requestFocus() } catch (_: Exception) { } }
                                        TextField(
                                            value = searchText,
                                            onValueChange = { searchText = it },
                                            placeholder = { Text("Pesquisar vídeos", color = TextMuted) },
                                            singleLine = true,
                                            colors = TextFieldDefaults.colors(
                                                focusedContainerColor = SurfaceDark, unfocusedContainerColor = SurfaceDark,
                                                focusedTextColor = TextMain, unfocusedTextColor = TextMain,
                                                focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
                                                cursorColor = Accent
                                            ),
                                            modifier = Modifier.fillMaxWidth().focusRequester(focus)
                                        )
                                    } else Brand()
                                },
                                actions = {
                                    IconButton(onClick = { if (searchActive) searchText = ""; searchActive = !searchActive }) {
                                        Icon(if (searchActive) Icons.Default.Close else Icons.Default.Search, "Pesquisar", tint = TextMain)
                                    }
                                },
                                colors = TopAppBarDefaults.topAppBarColors(containerColor = Bg)
                            )
                        }
                    },
                    bottomBar = {
                        NavigationBar(containerColor = Bg, contentColor = TextMain) {
                            listOf(Tab.HOME, Tab.SHORTS, Tab.UPLOAD, Tab.SUBSCRIPTIONS, Tab.YOU).forEach { tab ->
                                NavigationBarItem(
                                    selected = selectedTab == tab,
                                    onClick = {
                                        if (tab == Tab.UPLOAD) {
                                            importAsShort = false
                                            selectedTab = Tab.UPLOAD
                                        } else selectedTab = tab
                                    },
                                    icon = {
                                        when (tab) {
                                            Tab.HOME -> Icon(Icons.Default.Home, null)
                                            Tab.SHORTS -> Icon(Icons.Default.PlayArrow, null)
                                            Tab.UPLOAD -> Icon(Icons.Default.Add, null)
                                            Tab.SUBSCRIPTIONS -> Icon(Icons.Default.Subscriptions, null)
                                            Tab.YOU -> Icon(Icons.Default.Person, null)
                                        }
                                    },
                                    label = { Text(tab.label, fontSize = 10.sp) },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = TextMain,
                                        selectedTextColor = TextMain,
                                        indicatorColor = SurfaceDark,
                                        unselectedIconColor = TextMuted,
                                        unselectedTextColor = TextMuted
                                    )
                                )
                            }
                        }
                    }
                ) { padding ->
                    Box(Modifier.padding(padding).fillMaxSize()) {
                        when (selectedTab) {
                            Tab.HOME -> HomeScreen(videos, if (searchActive) searchText else "", prefs, onVideo = { selectedVideoUri = it.uri }, onRemove = { videoToRemove = it })
                            Tab.SHORTS -> ShortsScreen(videos.filter { it.isShort && (!searchActive || searchText.isBlank() || it.name.contains(searchText.trim(), true)) }, onVideo = { selectedShortUri = it.uri }, onRemove = { videoToRemove = it }, onAdd = {
                                importAsShort = true; picker.launch(arrayOf("video/*"))
                            })
                            Tab.UPLOAD -> UploadScreen(isImporting, importError, onPick = { asShort -> importAsShort = asShort; picker.launch(arrayOf("video/*")) })
                            Tab.SUBSCRIPTIONS -> EmptyScreen("Inscrições", "Seus canais e novidades poderão aparecer aqui.", Icons.Default.Subscriptions)
                            Tab.YOU -> LibraryScreen(videos, onVideo = { selectedVideoUri = it.uri }, onRemove = { videoToRemove = it }, onPick = { importAsShort = false; picker.launch(arrayOf("video/*")) })
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun Brand() {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Box(Modifier.size(width = 34.dp, height = 24.dp).clip(RoundedCornerShape(7.dp)).background(Accent), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.PlayArrow, null, tint = Color.White, modifier = Modifier.size(22.dp))
        }
        Text("MYTUBE", color = TextMain, fontWeight = FontWeight.Black, fontSize = 21.sp, letterSpacing = (-0.7).sp)
    }
}

@Composable
private fun HomeScreen(videos: List<LocalVideo>, query: String, prefs: android.content.SharedPreferences, onVideo: (LocalVideo) -> Unit, onRemove: (LocalVideo) -> Unit) {
    var category by remember { mutableStateOf("Todos") }
    val categories = listOf("Todos", "Jogos", "Música", "Minecraft", "Roblox")
    val searched = videos.filter { !it.isShort && (query.isBlank() || it.name.contains(query.trim(), true)) }
    val visible = searched.filter { video ->
        when (category) {
            "Minecraft" -> video.name.contains("minecraft", true)
            "Roblox" -> video.name.contains("roblox", true)
            "Música" -> listOf("música", "musica", "music", "song").any { video.name.contains(it, true) }
            "Jogos" -> listOf("game", "jogo", "minecraft", "roblox", "gta", "fortnite").any { video.name.contains(it, true) }
            else -> true
        }
    }
    val resumable = visible.filter { prefs.getLong(progressKey(it.uri), 0L) > 3_000L }
        .sortedByDescending { prefs.getLong("last_watched_${it.uri.hashCode()}", 0L) }
    val recommended = visible.filterNot { it in resumable }
        .sortedByDescending { prefs.getLong("last_watched_${it.uri.hashCode()}", 0L) }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 18.dp)) {
        item {
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                categories.forEach { label ->
                    Surface(color = if (category == label) Color.White else SurfaceDark, shape = RoundedCornerShape(9.dp), modifier = Modifier.clickable { category = label }) {
                        Text(label, color = if (category == label) Color.Black else TextMain, modifier = Modifier.padding(horizontal = 13.dp, vertical = 8.dp), fontSize = 13.sp, fontWeight = FontWeight.Medium)
                    }
                }
            }
        }
        if (visible.isEmpty()) {
            item { WelcomeCard() }
        } else {
            if (resumable.isNotEmpty()) {
                item {
                    Text("Continuar assistindo", color = TextMain, fontSize = 18.sp, fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(start = 14.dp, top = 12.dp, bottom = 8.dp))
                }
                items(resumable, key = { "resume_${it.uri}" }) { video -> VideoRow(video, onClick = { onVideo(video) }, onLongClick = { onRemove(video) }) }
                item {
                    Text("Todos os vídeos", color = TextMain, fontSize = 18.sp, fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(start = 14.dp, top = 12.dp, bottom = 8.dp))
                }
            }
            if (recommended.isNotEmpty()) {
                item {
                    Text(if (resumable.isEmpty()) "Recomendados para você" else "Mais vídeos", color = TextMain,
                        fontSize = 18.sp, fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(start = 14.dp, top = 12.dp, bottom = 8.dp))
                }
                items(recommended, key = { "video_${it.uri}" }) { video -> VideoRow(video, onClick = { onVideo(video) }, onLongClick = { onRemove(video) }) }
            }
        }
    }
}

@Composable
private fun WelcomeCard() {
    Column(Modifier.fillMaxWidth().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Box(Modifier.size(76.dp).clip(CircleShape).background(SurfaceDark), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.VideoLibrary, null, tint = Accent, modifier = Modifier.size(38.dp))
        }
        Text("Sua página inicial", color = TextMain, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text("Importe vídeos do seu celular para começar sua biblioteca. Eles ficam disponíveis offline.", color = TextMuted, fontSize = 14.sp)
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun VideoRow(video: LocalVideo, onClick: () -> Unit, onLongClick: () -> Unit = {}) {
    Column(Modifier.fillMaxWidth().combinedClickable(onClick = onClick, onLongClick = onLongClick).padding(bottom = 18.dp)) {
        Box(Modifier.fillMaxWidth().height(205.dp).background(Color(0xFF242424)), contentAlignment = Alignment.Center) {
            VideoThumbnail(video.uri, Modifier.fillMaxSize())
            Box(Modifier.align(Alignment.Center).size(48.dp).clip(CircleShape).background(Color.Black.copy(alpha = 0.55f)), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.PlayArrow, null, tint = Color.White, modifier = Modifier.size(34.dp))
            }
            Text("VÍDEO LOCAL", color = Color.White, fontSize = 10.sp,
                modifier = Modifier.align(Alignment.BottomStart).padding(10.dp))
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.Top) {
            Box(Modifier.size(38.dp).clip(CircleShape).background(Color(0xFF2E7D32)), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.PlayArrow, null, tint = Color.White)
            }
            Column(Modifier.weight(1f).padding(start = 10.dp)) {
                Text(video.name, color = TextMain, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text("Sua biblioteca · Segure para remover", color = TextMuted, fontSize = 12.sp)
            }
        }
    }
}


@Composable
private fun VideoThumbnail(uri: String, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val bitmap by produceState<Bitmap?>(initialValue = null, key1 = uri) {
        value = withContext(Dispatchers.IO) {
            val retriever = MediaMetadataRetriever()
            try {
                retriever.setDataSource(context, Uri.parse(uri))
                retriever.getFrameAtTime(1_000_000L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
            } catch (_: Exception) {
                null
            } finally {
                try { retriever.release() } catch (_: Exception) { }
            }
        }
    }
    if (bitmap != null) {
        Image(bitmap = bitmap!!.asImageBitmap(), contentDescription = "Miniatura de vídeo", modifier = modifier,
            contentScale = androidx.compose.ui.layout.ContentScale.Crop)
    } else {
        Box(modifier, contentAlignment = Alignment.Center) {
            Icon(Icons.Default.VideoLibrary, null, tint = TextMuted, modifier = Modifier.size(48.dp))
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ShortsScreen(shorts: List<LocalVideo>, onVideo: (LocalVideo) -> Unit, onRemove: (LocalVideo) -> Unit, onAdd: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.PlayArrow, tint = Accent, contentDescription = null, modifier = Modifier.size(28.dp))
            Text("Shorts", color = TextMain, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            TextButton(onClick = onAdd) { Text("Adicionar", color = TextMain) }
        }
        if (shorts.isEmpty()) {
            EmptyScreen("Seus Shorts", "Adicione vídeos curtos para montar seu feed pessoal.", Icons.Default.PlayArrow)
        } else {
            LazyColumn(contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(shorts, key = { it.uri }) { video ->
                    Box(
                        Modifier.fillMaxWidth().height(390.dp).clip(RoundedCornerShape(16.dp))
                            .background(Color(0xFF252525)).combinedClickable(onClick = { onVideo(video) }, onLongClick = { onRemove(video) }),
                        contentAlignment = Alignment.Center
                    ) {
                        VideoThumbnail(video.uri, Modifier.fillMaxSize())
                        Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.18f)))
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(Modifier.size(58.dp).clip(CircleShape).background(Color.Black.copy(alpha = 0.55f)), contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.PlayArrow, null, tint = Color.White, modifier = Modifier.size(42.dp))
                            }
                            Text(video.name, color = Color.White, fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.padding(12.dp), maxLines = 2, overflow = TextOverflow.Ellipsis)
                            Text("Toque para assistir", color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ShortsPlayerScreen(shorts: List<LocalVideo>, startUri: String, onBack: () -> Unit) {
    if (shorts.isEmpty()) {
        EmptyScreen("Nenhum Short disponível", "Adicione um vídeo curto para começar.", Icons.Default.PlayArrow)
        return
    }
    val initialIndex = shorts.indexOfFirst { it.uri == startUri }.coerceAtLeast(0)
    val pagerState = rememberPagerState(initialPage = initialIndex, pageCount = { shorts.size })
    BackHandler(onBack = onBack)
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        VerticalPager(
            state = pagerState,
            modifier = Modifier.fillMaxSize(),
            key = { page -> shorts[page].uri }
        ) { page ->
            ShortVideoPage(video = shorts[page], active = pagerState.currentPage == page)
        }
        Row(
            Modifier.align(Alignment.TopStart).fillMaxWidth().background(Color.Black.copy(alpha = 0.28f)).statusBarsPadding().padding(horizontal = 8.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Voltar", tint = Color.White)
            }
            Text("Shorts", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            Text("${pagerState.currentPage + 1}/${shorts.size}", color = Color.White.copy(alpha = 0.85f), fontSize = 12.sp,
                modifier = Modifier.padding(end = 12.dp))
        }
        Column(
            Modifier.align(Alignment.BottomStart).fillMaxWidth()
                .background(Color.Black.copy(alpha = 0.38f)).navigationBarsPadding().padding(horizontal = 18.dp, vertical = 20.dp)
        ) {
            Text(shorts[pagerState.currentPage].name, color = Color.White, fontSize = 16.sp,
                fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text("Vídeo local · Deslize para ver o próximo", color = Color.White.copy(alpha = 0.78f), fontSize = 12.sp,
                modifier = Modifier.padding(top = 5.dp))
        }
    }
}

@Composable
private fun ShortVideoPage(video: LocalVideo, active: Boolean) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val player = remember(video.uri) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(video.uri))
            repeatMode = androidx.media3.common.Player.REPEAT_MODE_ONE
            playWhenReady = false
            prepare()
        }
    }
    DisposableEffect(player, active, lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_PAUSE) player.pause()
            if (event == Lifecycle.Event.ON_RESUME && active) player.play()
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        if (active && lifecycleOwner.lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED)) player.play()
        else player.pause()
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
            player.pause()
        }
    }
    DisposableEffect(player) {
        onDispose { player.release() }
    }
    AndroidView(
        factory = { ctx -> PlayerView(ctx).apply {
            this.player = player
            useController = false
            setShutterBackgroundColor(android.graphics.Color.BLACK)
            resizeMode = androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIT
        } },
        update = { it.player = player },
        modifier = Modifier.fillMaxSize()
    )
}

@Composable
private fun UploadScreen(isImporting: Boolean, importError: String?, onPick: (Boolean) -> Unit) {
    var asShort by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(22.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(Icons.Default.Add, null, tint = Accent, modifier = Modifier.size(58.dp))
        Text("Adicionar vídeos", color = TextMain, fontSize = 23.sp, fontWeight = FontWeight.Bold)
        Text("Escolha um vídeo armazenado no seu Android.", color = TextMuted, fontSize = 14.sp)
        Spacer(Modifier.height(22.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Adicionar como Short", color = TextMain)
            Spacer(Modifier.width(10.dp))
            Switch(checked = asShort, onCheckedChange = { asShort = it }, colors = SwitchDefaults.colors(checkedTrackColor = Accent))
        }
        Spacer(Modifier.height(14.dp))
        Button(onClick = { onPick(asShort) }, enabled = !isImporting, colors = ButtonDefaults.buttonColors(containerColor = Accent), shape = RoundedCornerShape(24.dp)) {
            if (isImporting) CircularProgressIndicator(Modifier.size(18.dp), color = Color.White, strokeWidth = 2.dp)
            else Icon(Icons.Default.VideoLibrary, null)
            Spacer(Modifier.width(8.dp))
            Text(if (isImporting) "Importando vídeo..." else "Selecionar vídeo")
        }
        Text("O MYTUBE copia o vídeo para o armazenamento privado do aplicativo. O arquivo original permanece no celular.", color = TextMuted, fontSize = 11.sp, modifier = Modifier.padding(top = 16.dp))
        if (importError != null) Text(importError, color = Color(0xFFFF7777), fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp))
    }
}

@Composable
private fun LibraryScreen(videos: List<LocalVideo>, onVideo: (LocalVideo) -> Unit, onRemove: (LocalVideo) -> Unit, onPick: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Text("Você", color = TextMain, fontSize = 25.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(18.dp))
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(52.dp).clip(CircleShape).background(SurfaceDark), contentAlignment = Alignment.Center) { Icon(Icons.Default.Person, null, tint = TextMain, modifier = Modifier.size(30.dp)) }
            Column(Modifier.padding(start = 12.dp)) {
                Text("Minha biblioteca", color = TextMain, fontWeight = FontWeight.Bold)
                Text("${videos.size} vídeos adicionados", color = TextMuted, fontSize = 12.sp)
            }
        }
        Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedButton(onClick = onPick) { Icon(Icons.Default.Add, null); Text(" Importar") }
        }
        if (videos.isEmpty()) EmptyScreen("Biblioteca vazia", "Os vídeos que você importar aparecerão aqui.", Icons.Default.LibraryBooks)
        else LazyColumn { items(videos, key = { it.uri }) { v -> VideoRow(v, onClick = { onVideo(v) }, onLongClick = { onRemove(v) }) } }
    }
}

@Composable
private fun EmptyScreen(title: String, message: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Icon(icon, null, tint = Accent, modifier = Modifier.size(52.dp))
        Spacer(Modifier.height(12.dp))
        Text(title, color = TextMain, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text(message, color = TextMuted, fontSize = 14.sp)
    }
}

@Composable
private fun VideoPlayerScreen(
    video: LocalVideo,
    allVideos: List<LocalVideo>,
    prefs: android.content.SharedPreferences,
    onBack: () -> Unit,
    onNextVideo: (String) -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    var isExpanded by rememberSaveable(video.uri) { mutableStateOf(false) }
    var showControls by remember(video.uri) { mutableStateOf(true) }
    var showSettings by remember(video.uri) { mutableStateOf(false) }
    var shuffleEnabled by remember { mutableStateOf(prefs.getBoolean("shuffle_enabled", false)) }
    var resumeAfterLifecyclePause by remember(video.uri) { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    val nextVideo = remember(video.uri, allVideos, shuffleEnabled) {
        val eligible = allVideos.filter { it.uri != video.uri }
        if (eligible.isEmpty()) null
        else if (shuffleEnabled) eligible.random()
        else {
            val currentIndex = allVideos.indexOfFirst { it.uri == video.uri }
            allVideos.getOrNull(currentIndex + 1) ?: eligible.firstOrNull()
        }
    }

    val player = remember(video.uri) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(video.uri))
            val savedPosition = prefs.getLong(progressKey(video.uri), 0L)
            if (savedPosition > 3_000L) seekTo(savedPosition)
            prepare()
            playWhenReady = true
        }
    }

    fun revealControls() {
        showControls = true
        scope.launch {
            delay(3500)
            showControls = false
        }
    }

    BackHandler {
        if (showSettings) showSettings = false
        else if (isExpanded) isExpanded = false
        else onBack()
    }

    DisposableEffect(isExpanded) {
        val window = (context as? Activity)?.window
        val controller = window?.let { WindowCompat.getInsetsController(it, it.decorView) }
        if (isExpanded) {
            controller?.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            controller?.hide(WindowInsetsCompat.Type.systemBars())
        } else controller?.show(WindowInsetsCompat.Type.systemBars())
        onDispose { controller?.show(WindowInsetsCompat.Type.systemBars()) }
    }

    DisposableEffect(lifecycleOwner, player, video.uri) {
        recordWatch(prefs, video.uri)
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_PAUSE -> {
                    resumeAfterLifecyclePause = player.playWhenReady
                    savePlaybackProgress(prefs, video.uri, player.currentPosition, player.duration)
                    player.pause()
                }
                Lifecycle.Event.ON_RESUME -> {
                    if (resumeAfterLifecyclePause) player.play()
                    resumeAfterLifecyclePause = false
                }
                else -> Unit
            }
        }
        val completionListener = object : androidx.media3.common.Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == androidx.media3.common.Player.STATE_ENDED) {
                    prefs.edit().remove(progressKey(video.uri)).apply()
                }
            }
        }
        player.addListener(completionListener)
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            savePlaybackProgress(prefs, video.uri, player.currentPosition, player.duration)
            player.removeListener(completionListener)
            lifecycleOwner.lifecycle.removeObserver(observer)
            player.release()
        }
    }

    LaunchedEffect(video.uri, showControls) {
        if (showControls) {
            delay(3500)
            showControls = false
        }
    }

    Column(
        Modifier.fillMaxSize().background(if (isExpanded) Color.Black else Bg)
            .then(if (isExpanded) Modifier else Modifier.systemBarsPadding())
    ) {
        if (!isExpanded) {
            Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Voltar", tint = TextMain) }
                Text(video.name, color = TextMain, fontWeight = FontWeight.SemiBold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }

        Box(
            Modifier.fillMaxWidth()
                .then(if (isExpanded) Modifier.weight(1f) else Modifier.aspectRatio(16f / 9f))
                .background(Color.Black)
                .clickable { revealControls() }
        ) {
            AndroidView(
                factory = { ctx ->
                    PlayerView(ctx).apply {
                        this.player = player
                        useController = false
                        setShutterBackgroundColor(android.graphics.Color.BLACK)
                        resizeMode = androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIT
                    }
                },
                update = { view ->
                    view.player = player
                    view.resizeMode = androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIT
                },
                modifier = Modifier.fillMaxSize()
            )

            if (showControls) {
                Row(
                    Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                        .background(Color.Black.copy(alpha = 0.58f))
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { if (player.isPlaying) player.pause() else player.play(); revealControls() }) {
                        Icon(if (player.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = if (player.isPlaying) "Pausar" else "Reproduzir", tint = Color.White)
                    }
                    Spacer(Modifier.weight(1f))
                    IconButton(onClick = { showSettings = true; revealControls() }) {
                        Icon(Icons.Default.Settings, "Configurações de reprodução", tint = Color.White)
                    }
                    IconButton(onClick = { nextVideo?.let { onNextVideo(it.uri) } }, enabled = nextVideo != null) {
                        Icon(Icons.Default.SkipNext, "Próximo vídeo", tint = if (nextVideo != null) Color.White else TextMuted)
                    }
                    IconButton(onClick = { isExpanded = !isExpanded; revealControls() }) {
                        Icon(if (isExpanded) Icons.Default.FullscreenExit else Icons.Default.Fullscreen,
                            contentDescription = if (isExpanded) "Sair da tela cheia" else "Tela cheia",
                            tint = Color.White)
                    }
                }
            }
        }

        if (!isExpanded) {
            Text(video.name, color = TextMain, fontSize = 19.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(16.dp))
            Text("Vídeo da sua biblioteca · Reprodução local", color = TextMuted, fontSize = 13.sp,
                modifier = Modifier.padding(horizontal = 16.dp))
            if (nextVideo != null) {
                Text("Próximo vídeo", color = TextMain, fontSize = 16.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(start = 16.dp, top = 22.dp, bottom = 8.dp))
                VideoRow(nextVideo, onClick = { onNextVideo(nextVideo.uri) }, onLongClick = {})
            }
        }
    }

    if (showSettings) {
        AlertDialog(
            onDismissRequest = { showSettings = false },
            title = { Text("Configurações de reprodução") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Ordem de reprodução")
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Reprodução aleatória", modifier = Modifier.weight(1f))
                        Switch(
                            checked = shuffleEnabled,
                            onCheckedChange = {
                                shuffleEnabled = it
                                prefs.edit().putBoolean("shuffle_enabled", it).apply()
                            }
                        )
                    }
                    Text("O botão Próximo respeita esta opção.")
                }
            },
            confirmButton = { TextButton(onClick = { showSettings = false }) { Text("Concluir") } }
        )
    }
}

private fun copyVideoToPrivateStorage(context: Context, source: Uri, displayName: String): Uri {
    val directory = File(context.filesDir, "videos").apply { if (!exists() && !mkdirs()) error("Não foi possível criar a pasta de vídeos") }
    val extension = queryFileExtension(context, source).ifBlank { "mp4" }
    val safeExtension = extension.filter { it.isLetterOrDigit() }.take(8).ifBlank { "mp4" }
    val destination = File(directory, "${UUID.randomUUID()}.$safeExtension")
    try {
        val input = context.contentResolver.openInputStream(source) ?: error("Não foi possível abrir o vídeo selecionado")
        input.use { stream -> FileOutputStream(destination).use { output -> stream.copyTo(output, 1024 * 1024); output.fd.sync() } }
        if (!destination.exists() || destination.length() == 0L) error("O arquivo importado está vazio")
        return Uri.fromFile(destination)
    } catch (e: Exception) {
        destination.delete()
        throw e
    }
}

private fun queryFileExtension(context: Context, uri: Uri): String {
    val name = try {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
    } catch (_: Exception) { null }
    return name?.substringAfterLast('.', "")?.lowercase().orEmpty()
}

private fun deletePrivateVideoIfOwned(context: Context, uriString: String) {
    try {
        val uri = Uri.parse(uriString)
        if (uri.scheme != "file") return
        val file = File(uri.path ?: return).canonicalFile
        val ownedDirectory = File(context.filesDir, "videos").canonicalFile
        if (file.parentFile == ownedDirectory) file.delete()
    } catch (_: Exception) { }
}

private fun loadVideos(prefs: android.content.SharedPreferences): List<LocalVideo> {
    val json = prefs.getString("videos_json", null)
    if (json != null) {
        return try {
            val arr = JSONArray(json)
            (0 until arr.length()).map { idx ->
                val o = arr.getJSONObject(idx)
                LocalVideo(o.getString("uri"), o.getString("name"), o.optBoolean("short", false))
            }
        } catch (_: Exception) { emptyList() }
    }
    // Migração do formato antigo (1.4 e anteriores)
    return prefs.getStringSet("videos", emptySet()).orEmpty().mapNotNull { line ->
        val parts = line.split("\t")
        if (parts.size >= 3) LocalVideo(parts[0], parts[1], parts[2] == "1") else null
    }
}

private fun saveVideos(prefs: android.content.SharedPreferences, videos: List<LocalVideo>) {
    val arr = JSONArray()
    videos.forEach { arr.put(JSONObject().put("uri", it.uri).put("name", it.name).put("short", it.isShort)) }
    prefs.edit().putString("videos_json", arr.toString()).remove("videos").apply()
}

private fun queryDisplayName(context: Context, uri: Uri): String {
    val fromProvider = try {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
    } catch (_: Exception) { null }
    val raw = fromProvider ?: uri.lastPathSegment?.substringAfterLast('/') ?: "Vídeo importado"
    return raw.substringBeforeLast('.', raw).ifBlank { "Vídeo importado" }
}

private fun progressKey(uri: String): String = "playback_progress_${uri.hashCode()}"

private fun savePlaybackProgress(
    prefs: android.content.SharedPreferences,
    uri: String,
    position: Long,
    duration: Long
) {
    if (position > 3_000L && (duration <= 0L || position < duration - 3_000L)) {
        prefs.edit().putLong(progressKey(uri), position).apply()
    } else if (duration > 0L && position >= duration - 3_000L) {
        prefs.edit().remove(progressKey(uri)).apply()
    }
}

private fun recordWatch(prefs: android.content.SharedPreferences, uri: String) {
    prefs.edit().putLong("last_watched_${uri.hashCode()}", System.currentTimeMillis()).apply()
}
